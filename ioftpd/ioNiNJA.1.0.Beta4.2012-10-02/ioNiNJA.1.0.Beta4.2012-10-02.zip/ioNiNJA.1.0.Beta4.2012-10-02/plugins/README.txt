So what are the scripts?

/wrapper
check wrapper.itcl for more info

cduniverser.xxx.itcl = Downloads XXX info and covers for english porn movies/sorts them
gamespy              = Download Gameinfo from GameSpy.com and sorts (broken)
imdb                 = Sorts imdb for movies, downloads covers and backdrops
music_video          = Sorts Music Videos, creates musicvideo bar, download covers etc
xxx                  = Sorts XXX, creates xxx bar
regexp_sorting       = Sorts after Regexp
tv                   = sorts tv from tvrage, downloads cover/backdrop, add a tv bar
ioTV                 = TheTvDB.com plugin, downloads, covers, info, backdrop etc.
unpack_complete      = Unpacks complete releases, srr, rename, bla bla bla
mp3                  = MP3 Sorting and downloads cover


1.	%a %A %b %B %C %d %e %g %G %h %I %j %k %l %m %M %p %u %U %V %w %W %y %Y
	These variables are Time variables avalible for all sorting. imdb/tv/mp3/mv/regexp etc
	But think before you use them
	To find out what they are check:
	http://www.tcl.tk/man/tcl8.4/TclCmd/clock.htm
	Notice that it is case sensetive
	
	
	