+--------------------------------------------------------------------------------+
|                                                                                |
|  PLEASE READ THIS ENTIRE FILE SO U WON'T ASK QUESTIONS THAT ARE ANSWERED HERE  |
|                                                                                |
+--------------------------------------------------------------------------------+

+---+----------------------------+
| 1 | Installation on the server |
+---+----------------------------+

  - Choose between ioGuiExt.exe and ioGuiExt.itcl, see below for differences.
    Copy the file to C:\ioFTPD\scripts\ or wherever u installed ioFTPD.

  - Edit ioFTPD.ini:
  
    [FTP_Custom_Commands]
    ioGuiExt = EXEC ..\scripts\ioGuiExt.exe
    OR:
    ioGuiExt = TCL ..\scripts\ioGuiExt.itcl

    [FTP_SITE_Permissions]
    ioGuiExt = M

  - Don't forget to rehash!


+---+----------------------------+
| 2 | Installation on the client |
+---+----------------------------+

  still not what it's supposed to be :/

  - settings changes mostly require a restart to take effect
  - adding/editing sites can be done in the Gui
  - edit sites.ini & settings.ini manually, if needed

  if u need AUTH TLS, take a look at winsslwrap.config.jpg


+---+-------------+
| 3 | Information |
+---+-------------+

  - Compatible with all ioFTPD versions since 5.2.11
    Recommended version at this moment: 5.8.5r

  - ioGuiExt.exe may hang on ioFTPD 5.8.4, upgrade to 5.8.5 if possible.

  - Should be compatible with the SharedDB module,
    but I haven't been able to test this myself.

  - 'Visual' settings are stored in the registry, in this key :
    HKEY_CURRENT_USER\Software\VB and VBA Program Settings\ADDiCT ioTools\ioGui2

    Incase of 'visual problems', eg. the ioGui2 window doesn't show up
    when u click the trayicon, try erasing these registry values.
    U can do this by doubleclicking on clear.registry.settings.reg.

  - ioGui2 can edit the M (master) flag. This will show a warning when u give
    or take the flag.  Not possible with batch commands (for safety reasons).
    If u want to delete a master user, u must first remove his M flag.

  - ioGui2.nodebug.exe is a version without debug info. Smaller & faster.
    But if an error occurs, I can't find out where it came from, so only use
    it if performance is much more important for u than possible bugfixes.
    It's written in VB so it's slow anyway (h) (y)

  - Differences between ioGuiExt.exe and ioGuiExt.itcl :
    * The EXE will be slower on high server load, since a process needs to 
      be created every time, while the iTCL script is cached in ioFTPD.
    * The EXE suffers from possible shmem problems, the iTCL from possible
      iTCL problems. At this moment, both work good on my test system.
    * In the activity list, the iTCL script doesn't show on which
      service a user is logged in. If this information is important
      for u, i suggest using the EXE.
    * The EXE does not support copying users (yet).
    * If later, I add extra information like system uptime, mem usage, ...
      an EXE script will still be required, besides the iTCL.


+---+-----------+
| 4 | Gui guide |
+---+-----------+

  - Click on the G icon in the left bottom for the config menu !

  - Rightclicking on the main tabstrip wil toggle single-site mode
    This is usefull when u only have one site, or u need a larger view
    on a single site.

  - Doubleclicking on a user in the groups members list, or
    doubleclicking on a group in the users groups list,
    will take u to that user/group.

  - A user with flag 1 is considered an admin, he gets an 'A' next to his name.

  - Doubleclick the credits/ratio table in the user settings to edit it.

  - The checkbox in the right top, below the close X-button,
    is to make ioGui2 stay on top of other windows.


+---+------------------------------------------+
| 5 | window caption / trayicon text variables |
+---+------------------------------------------+

NOTE: all variables apply to the currently selected site

%(sitename)            name of the currently selected site

%(online_all)          number of online users
%(online_transfer)     number of transferring (up+down) users
%(online_up)           number of uploading users
%(online_down)         number of downloading users
%(online_idle)         number of idle users

%(bandwidth_total)     current bandwidth in use (up+down)
%(bandwidth_up)        bandwidth in use by uploads
%(bandwidth_down)      bandwidth in use by downloads


+---+---------------------+
| 6 | About menu commands |
+---+---------------------+

$command --> execute command immediately
%command --> ask user for confirmation

global:
-------
$null      (do nothing)
$ftp       send a command to the currently selected site
$exec      start a program / open a file on your computer
$kill      kill a process on your computer
$exit      close ioGui2

only for browser:
-----------------
$nuke      show nuke dialog window
$wipe      show wipe dialog window
$chattr    show chattr dialog window
$chmod     show chmod dialog window

only for userlist:
------------------
$copyuser  shows copuser dialog window


+---+----------------------------------------+
| 7 | About batch commands (in usersettings) |
+---+----------------------------------------+

  Select all users u want to change in the userlist,
  then select the things u want to change.

  U can also perform a custom (site)command on all selected users, the
  word %user will each time be replaced with one of the selected users.

  To see the results, check the 'Command Results' tab. U can use it to
  find out if a certain command failed on one of the users.

