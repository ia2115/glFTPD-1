Do NOT even THINK of installing ioFTPD as a service until the server runs
standalone without issues!

Service can be configured and controlled via the Services Administrative Tool
which can be found via: Control Panel->Administrative Tools->Services or via
primitive command line tools.



BENEFITS:
---------

The benefits to running ioFTPD as a service are:
  1) The server starts automatically when the computer is turned on.
  2) It restarts whenever the server crashes.
  3) You can start/stop the server via the command line using
       net start ioFTPD
       net stop ioFTPD

The potential drawbacks are:
  1) You must use ioFTPD.ini as your configuration file since right now you
     can't specify a different file to use when starting the server.
  2) Trickier configuration.



IMPORTANT CONSIDERATIONS:
-------------------------

1) Services generally run as under the Local System account (i.e. the
   "System" user).  This is a very priviledged account with full
   administrator rights, but it has no network privileges and thus cannot
   access remote shared filesystems.  If you need to mount network shares
   in your VFS then use the "Log On As" option and specify a user who has
   the appropriate network rights.  Do NOT think about granting network
   privileges to the system account!

2) ioFTPD doesn't need administrator rights so I suggest running the service
   as a limited rights account.  This will limit the potential for ioFTPD
   to harm the system if something bad happens.

3) When Windows boots up and begins starting services the start order is very
   important since services often depend upon one another.  The actual list
   of services include many builtin Windows services/drivers that don't show
   up in the services control panel.  By default the ioFTPD service is
   configured to depend upon 2 other services: Tcpip and Afd (the kernel
   mode driver that supports Windows Socket applications).  If however you
   are using network shares you might need to add the Network Redirector
   (lanmanworkstation) to the dependency list.  You'll need to manually
   edit the registry and add "lanmanworkstation" to:
     HKEY_LOCAL_MACHINE\CurrentControlSet\ioFTPD\DependOnService
   If there are other requirements such as RPC being available if a script
   uses it on startup just add the services to the above registry value.

4) If you have a dynamic IP address obtained only when the user logs into
   the computer (such as some software point to point tunneling protocols,
   VPN, or custom software from your ISP) then the server will very likely
   start up before the network is configured.  This is OK since the server
   will reconfigure itself every 10 minutes when the ConfigUpdate event
   is executed.  You may wish to script a solution, however, to issue a
   "site config rehash" to force the update once you know you are connected,
   any dynamic hostnames are updated, etc.

5) Be aware of file/directory permission issues when running as a service
   especially when running as a different user.  Make triple sure the
   ioFTPD.ini file is readable since without it the server won't know where
   the logfiles are and it can't report problems...



INSTALLING:
-----------

1) To install the service just click the ServiceInstaller.exe file and it
   brings up a window asking if you want to install the "ioFTPD" service.

2) After clicking Yes the service is installed but not running so it asks
   you if it should start it.  If you don't wish to modify any of the default
   settings described below feel free to start the server.  If you do need
   to make changes then select No, make the changes, and start the server
   from the services control panel.

Default settings (Control Panel->Administrative Tools->Services->ioFTPD):
General Tab:
  Startup type: Automatic

Log On tab:
  Log on as: Local System account.
-->  I suggest changing this to your personal account or a limited user
     account.  Just select the "This Account" radio box and enter the
     login info.  I might have made this the default had I not had to
     ask for your password.

Recover Tab:
  First Failure: Restart
  Second Failure: Take no action

  Reset Fail Count after: 10 minutes (NOTE: the listed field is in DAYS and
     therefor 10 minutes shows up as 0 - I don't know how you set it to
     a different small value through the services control panel).

  Restart service after: 1 minutes (time to wait after failure before
     starting it again.

--> With these settings the server will restart 1 minute after a failure
    but only if it hasn't failed within the last 10 minutes.  This prevents
    a serious error crashing the server from thrashing.

   

UNINSTALLING:
-------------

1) To un-install the service just click the ServiceInstaller.exe file and
   it will bring up a window asking if you want to stop the server and
   uninstall the service.  In rare cases the service may end up in a "marked
   for deletion" state which would prevent you from immediately re-installing
   the service.  If that happens try closing the Services window as that
   usually allows the service to be deleted.




DEBUGGING:
----------

1) Check the event log (Control Panel->Administrative Tools->Events Viewer).

2) If you are running under an account other than Local System log in as that
   user and try and start the server and see if that works.

3) Verify permissions to all directories, files, etc.  Especially ioFTPD.ini.

4) Double check that the server runs when started normally.
