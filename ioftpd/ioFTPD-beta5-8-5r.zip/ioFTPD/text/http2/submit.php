<?php

    setcookie("foo", "bar r�tt�_d��");
    setcookie("boo", "bar r�tt�_d��");
    phpinfo();

    if (isset($_POST["submit"]))
    {

        echo "<PRE>\n";
        print_r($_POST);
        echo "</PRE>\n";
        
        
    } else {

?>

<table height="100%" width="100%">
<tr>
<td valign="middle" align="center">
 <form name="frmSearch" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
    <table border="1">
        <tr> 
            <td>Name contains:</td>
            <td><input type="text" name="txtName"></td>
        </tr>
        <tr> 
            <td>Type:</td>
            <td><select name="txtType">
                    <option selected>X</option>
                    <option>Y</option>
                    <option>Z</option>
                </select></td>
        </tr>
        <tr> 
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr> 
            <td>Sort results by:</td>
            <td><select name="txtSortBy">
                <option selected>A</option>	
                <option>B</option>	
                <option>C</option>	
                </select></td>
        </tr>
        <tr> 
            <td>Results per page:</td>
            <td><select name="txtResultsPerPage">
                    <option>5</option>
                    <option selected>10</option>
                    <option>20</option>
                    <option>50</option>
                </select></td>
        </tr>
        <tr> 
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr> 
            <td colspan="2"><div align="center"> 
                    <input type="submit" name="submit" value="Search">
                </div></td>
        </tr>
    </table>
</form>
</td>
</tr>
</table>


<?php

    }

?>