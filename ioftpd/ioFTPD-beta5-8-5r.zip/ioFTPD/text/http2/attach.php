<?php
	header('Content-type: text/plain');
	header('Content-Disposition: attachment; filename="ioFTPD-beta5-6-3u.zip"');
	io_attachment('d:\\ioFTPD-beta5-6-3u.zip');
?>