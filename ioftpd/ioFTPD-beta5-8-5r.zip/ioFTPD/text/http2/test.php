<head>foo<br></head>
<body>
<?php
	

	function getmicrotime() 
	{ 
	   list($usec, $sec) = explode(" ", microtime()); 
	   return (((float)$usec / 1000) + (float)$sec); 
	}

	$uid = io_user_id('ioFTPD');
	$uhandle = io_user_open($uid);
	$text = io_user_print($uhandle);
	io_user_lock($uhandle);

	io_user_close($uhandle);

	$ulist = io_user_list_init();
	while (($id = io_user_list_fetch($ulist)) >= 0) {
		$uname = io_user_name($id);
		echo "User: $uname<br>";
	}
	io_user_list_close($ulist);

	$file = io_fs_open('d:/ioFTPD/site/home/ioFTPD');
	$finfo = io_fs_query($file);
	$uname = io_user_name($finfo[0]);

	echo "Uid :$finfo[0]<br>";
	echo "Gid :$finfo[1]<br>";
	echo "Mode:$finfo[2]<br>";
	
	io_fs_modify($file, 101, 101);
	io_fs_write($file);

	io_fs_close($file);

	$uhandle = io_user_open(io_user_id('darkone'));

	$file = io_fs_open('d:/ioFTPD/site/home/ioFTPD');
	$finfo = io_fs_query($file);

	if (io_fs_access($file, $uhandle, FS_EXECUTE)) {
		echo "Has access!<br>";
	} else {
		echo "No access!<br>";
	}

	echo "Uid :$finfo[0]<br>";
	echo "Gid :$finfo[1]<br>";
	echo "Mode:$finfo[2]<br>";

	io_fs_modify($file, 0, 0);
	io_fs_write($file);
	io_fs_close($file);
	io_user_close($uhandle);


	if (isset($_GET['path'])) {
		$path = $_GET['path'];
	} else {
		$path = '/';
	}


	echo "Client list:<br>";
	# Fetch user list
	$clist = io_client_list_init(CINFO_CID, CINFO_UID, CINFO_HOSTNAME, CINFO_IDENT);
	if ($clist) {
		while (($data = io_client_list_fetch($clist))) {
			echo "<a href=\"test.php?path=$path&cid=$data[0]\">Kill</a> Cid: $data[0] Uid: $data[1] Host: $data[3]@$data[2]<br>";
		}
		io_client_list_close($clist);
	}
	if (isset($_GET['cid'])) {
		io_client_kill($_GET['cid']);
	}
	echo "<br>";



	$start = getmicrotime();

	# Initialize query mask
	$mask = io_user_mask_init(UINFO_MOUNTFILE);
	
	# Open userfile
	$uhandle = io_user_open(0);

	# Get mountfile
	$uvars = io_user_query($uhandle, $mask);
	if (! $uvars[0]) {
		$uvars[0] = io_config_get_string('Locations', 'Default_Vfs');
	}
	io_user_mask_close($mask);
	
	# Open mount table
	$mtable = io_mtable_open($uvars[0]);

	# Resolve root path
	$path = io_mtable_query($mtable, $path, $uhandle, 1);
	$c_path = count($path);

	if ($c_path > 1) {
		# Show mounts under current path
		$link = io_mtable_query_mounts($mtable, $path[0]);
		$path[0] = urlencode($path[0]);
		echo "<a href=\"test.php?path=$path[0]..\">..</a><br>";
		if ($link) {
			$c_link = count($link);
			for ($i=0;$i<$c_link;$i+=2) {
				# Open file vfs attributes
				$file = io_fs_open($link[$i+1]);

				# Test access
				if ($file && io_fs_access($file, $uhandle)) {
					$finfo = io_fs_query($file);
					echo "$finfo[0]:$finfo[1] <a href=\"test.php?path=$path[0]$link[$i]\">$link[$i]</a><br>";
				}
				io_fs_close($file);
			}
		}

		# Go through result path array
		for ($i=1;$i<$c_path;$i++) {
			$hfind = io_fs_find_first($path[$i]);
			# Show files
			if ($hfind) {
				do {
					if (io_fs_isdirectory($hfind)) {
						if (io_fs_access($hfind, $uhandle)) {
							$finfo = io_fs_query($hfind);
							$fname = io_fs_query_filename($hfind);
							$flink = urlencode($fname);
							echo "$finfo[0]:$finfo[1] <a href=\"/test.php?path=$path[0]$flink\">$fname</a><br>";
						}
					} else {
						$finfo = io_fs_query($hfind);
						$fname = urlencode(io_fs_query_filename($hfind));
						echo "$finfo[0]:$finfo[1] <a href=\"/test.php?path=$path[0]$link\">$fname</a><br>";
					}

				} while (io_fs_find_next($hfind));
				io_fs_find_close($hfind);
			}
		}
	} else {
		echo "Could not access requested directory<br>";
	}
	

	io_mtable_close($mtable);
	io_user_close($uhandle);

	$end = getmicrotime();
	$time = $end - $start;
	echo "<br>List took $time seconds to execute";


	phpinfo();
	echo "<br>";

?>
</body>
