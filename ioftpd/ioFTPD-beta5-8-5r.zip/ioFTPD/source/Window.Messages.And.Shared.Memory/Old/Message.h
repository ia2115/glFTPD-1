#define MAX_GROUPS			25
#define MAX_IPS				25
#define MAX_SECTIONS		10
#define MAX_HOSTNAME		96
#define MAX_IDENT			64
#define _MAX_PWD			512
#define _IP_LINE_LENGTH		96

#define WM_KICK				(WM_USER + 6)	// Send uid as WPARAM to kick user
#define WM_WHO				(WM_USER + 11)	// Send iPos as WPARAM and memory address of STATIC structure as lparam (win95/98/me) to receive who data
#define WM_CHECKLOGINS		(WM_USER + 13)	// Send Uid as WPARAM and service type as LPARAM to receive user's current login count for service
#define WM_KILL				(WM_USER + 15)	// Kill specific connection, iPos as WPARAM
#define WM_WHO_SHARED		(WM_USER + 16)	// Send iPos as WPARAM and memory address returned by WM_SHMEM_ALLOC as lparam (winnt/2k/xp) to receive who data
#define WM_PHANDLE			(WM_USER + 17)	// Returns ioFTPDs current process handle
#define WM_SHMEM_ALLOC		(WM_USER + 18)	// 
#define WM_SHMEM_FREE		(WM_USER + 19)	//


/*

  *NOTE* These structures are not final

  */



typedef struct _USERFILE
{
	CHAR			*name;					// Only accessible for ioftpd
	CHAR			tagline[128 + 1];		// Info line
	CHAR			vfsfile[_MAX_PATH + 1];	// Root directory
	CHAR			Home[_MAX_PATH + 1];	// Home directory
	CHAR			flags[32 + 1];			// Flags
	INT				Logins[3];				// Maximum concurrent logins
	INT				SpeedLimit[2];			// Up and down speedlimits (kb/sec * 10)

	INT				uid;					// User id
	INT				gid;					// User group id
	UCHAR			password[20];			// Password

	INT				ratio[MAX_SECTIONS];	// Ratio
	INT64			credits[MAX_SECTIONS];	// Credits

	INT64			dayup[MAX_SECTIONS * 3];	// Daily uploads
	INT64			daydn[MAX_SECTIONS * 3];	// Daily downloads
	INT64			wkup[MAX_SECTIONS * 3];		// Weekly uploads
	INT64			wkdn[MAX_SECTIONS * 3];		// Weekly downloads
	INT64			monthup[MAX_SECTIONS * 3];	// Monthly uploads
	INT64			monthdn[MAX_SECTIONS * 3];	// Monthly downloads
	INT64			allup[MAX_SECTIONS * 3];	// Alltime uploads
	INT64			alldn[MAX_SECTIONS * 3];	// Alltime downloads

	INT				AdminGroups[MAX_GROUPS];	// Admin for these groups
	INT				groups[MAX_GROUPS];					// List of groups
	CHAR			ip[MAX_IPS][_IP_LINE_LENGTH + 1];	// List of ips

	VOID			*Parent;					// Internal var (ioftpd)
	BOOL			Loaded;						// ...

	DWORD			dSync;						// ...

} USERFILE;




typedef struct _STATIC
{
	USERFILE	UserFile;					// Userfile Structure
	UCHAR		ServiceType;				// Type of service (0 FTP, 1 TELNET, 2 HTTP)
	UCHAR		Dead;						// Connection has been killed (killed connections are not counted in user's total login count)
	CHAR		ServiceName[64];			// Name of service
	CHAR		Action[64];					// User's last action
	sockaddr_in	Host;						// Client's internet address
	CHAR		HostName[MAX_HOSTNAME];		// Hostname
	CHAR		Ident[MAX_IDENT];			// Ident
	CHAR		Path[_MAX_PWD + 1];			// Path

	time_t		Login;						// Login Time
	DWORD		Idle;						// Idle Time

	UCHAR		Transfer;					// (0 Inactive, 1 Upload, 2 Download, 3 List)
	sockaddr_in	DataHost;					// Client's data sockets (if any) internet address
	CHAR		DataFile[_MAX_PWD + 1];		// File being transfered
	DWORD		Transfered;					// Bytes transfered during interval
	DWORD		Interval;					// Milliseconds
	INT64		TotalTransfered;			// Total bytes transfered during transfer

	//	Not Important

	VOID		*Service;

} STATIC;