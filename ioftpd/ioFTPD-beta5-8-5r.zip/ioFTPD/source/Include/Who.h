#define	W_IDLE		0
#define W_LIST		1
#define W_UPLOAD	2
#define W_DOWNLOAD	3
#define W_LOGIN		4




typedef struct _IO_WHO
{
	DWORD			dwConnectionId;
	LPTSTR			tszAction;
	LPTSTR			tszServiceName;
	LPSTR			szHostName;
	LPSTR			szIdent;
	LONG			lNetworkAddress;
	LPUSERFILE		lpUserFile;

	LPTSTR			tszPath;
	LPTSTR			tszVirtualPath;
	LPTSTR			tszDataPath;
	LPTSTR			tszVirtualDataPath;

	INT64			i64FileSize;
	INT64			i64TotalBytesTransfered;

	DOUBLE			fTransferSpeed;
	DOUBLE			fUpSpeed;
	DOUBLE			fDnSpeed;

	DWORD			dwUploads;
	DWORD			dwDownloads;
	DWORD			dwUsers;

	DWORD			dwLoginHours;
	DWORD			dwLoginMinutes;
	DWORD			dwLoginSeconds;

	DWORD			dwIdleHours;
	DWORD			dwIdleMinutes;
	DWORD			dwIdleSeconds;

} IO_WHO, * LPIO_WHO;