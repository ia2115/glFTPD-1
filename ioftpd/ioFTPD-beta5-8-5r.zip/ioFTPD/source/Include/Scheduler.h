typedef struct _SCHEDULER_SET
{
	INT			Min;
	INT			Max;
	BOOLEAN		All;

} SCHEDULER_SET;




typedef struct _SCHEDULED_TASK
{
	LPTSTR					tszName;

	BYTE					Minute[8];
	SCHEDULER_SET			MinuteSet;

	BYTE					Hour[4];
	SCHEDULER_SET			HourSet;

	BYTE					DayOfWeek[1];
	SCHEDULER_SET			DayOfWeekSet;

	BYTE					DayOfMonth[5];
	SCHEDULER_SET			DayOfMonthSet;

	LPTSTR					tszCommandLine;
	BOOL					bFlagged;
	LONG volatile			lShareCount;
	FILETIME				Time;
	struct _SCHEDULED_TASK	*lpNext;

} SCHEDULED_TASK, * LPSCHEDULED_TASK;


BOOL Scheduler_Init(BOOL bFirstInitialization);
VOID Scheduler_DeInit(VOID);

