typedef struct _DATA
{
	IOFILE				IoFile;
	IOSOCKET			Socket;
	LPVOID				lpSocketEvent;
	struct sockaddr_in	Address;				//	Address of client in datasocket
	DWORD				dwLastError;			//	Last error

	VIRTUALPATH			File;
	INT64				Charged;				// Kilobytes charged from transfer
	INT64				Size;					// Size of last transfer
	DWORD				dwResumeOffset[2];

	UCHAR				bActive				: 1;
	UCHAR				bInitialized		: 1;
	UCHAR				bProtected			: 1;
	UCHAR				bProtectedConnect	: 1;
	UCHAR				bAbort				: 1;

	UCHAR				bEncoding		: 1;
	UCHAR				bTransferMode	: 1;
	UCHAR				bDirection		: 1;
	UCHAR				bSpecial		: 1;
	UCHAR				bFree			: 1;

	TIME_STRUCT			Start;
	TIME_STRUCT			Stop;

	BUFFER				Buffer;

} DATA, FTP_DATA, * PDATACHANNEL, DATACHANNEL, * LPDATACHANNEL;


#define	ASCII	TRUE
#define	BINARY	FALSE
#define	ACTIVE	TRUE
#define PASSIVE	FALSE
#define SEND	TRUE
#define RECEIVE	FALSE
#define LIST	TRUE
