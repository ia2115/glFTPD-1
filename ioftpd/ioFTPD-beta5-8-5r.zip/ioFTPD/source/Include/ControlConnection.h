typedef struct _COMMAND
{
	IOSOCKET			Socket;
	CHAR				Action[64];

	INT					ErrorCode;
	BOOL				TooLong;
	INT					Prefix;
	VIRTUALPATH			Path;

	LPSTR				Command;
	DWORD				Length;

	DWORD				Idle;
	BUFFER				In;
	BUFFER				Out;

} COMMAND, * LPCOMMAND;


#define	U_LOGIN			0000L
#define U_IDENTIFIED	0001L
#define U_LOGOFF		0002L
#define U_MAKESSL		0010L
#define	U_KILL			0020L
#define U_IDENT			0100L