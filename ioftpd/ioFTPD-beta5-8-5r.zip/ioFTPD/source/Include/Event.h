//	Structure passed to event module on initialization
typedef struct _EVENT_MODULE
{
	LPSTR					szName;
	LPVOID					(* lpGetProc)(LPSTR);
	BOOL					(* lpInstallEvent)(LPSTR, LPVOID);
	HMODULE					hModule;
	struct _EVENT_MODULE	*lpNext;

} EVENT_MODULE, * LPEVENT_MODULE;


//	Structure used for emulating blocking send using completion port
typedef struct _REDIRECT_WAIT
{
	LPIOSOCKET	lpSocket;
	HANDLE		hEvent;
	DWORD		dwError;
	DWORD		dwBufferLength;
	DWORD		dwBufferOffset;
	PCHAR		pBuffer;

} REDIRECT_WAIT, * LPREDIRECT_WAIT;


//	Structure passed to event module proc
typedef struct _EVENT_DATA
{
	LPTSTR			tszPrefix;
	DWORD			dwPrefix;
	LPIOSOCKET		lpSocket;
	LPBUFFER		lpBuffer;
	LPVOID			lpData;
	DWORD			dwData;
	DWORD			dwFlags;
	VOID			(* lpCallbackProc)(LPVOID, BOOL);
	LPVOID			lpCallbackContext;

} EVENT_DATA, * LPEVENT_DATA;

//	Internal structure
typedef struct _EVENT_PROC
{
	LPSTR	szName;
	LPVOID	lpProc;

} EVENT_PROC, * LPEVENT_PROC;

//	Internal structure
typedef struct _Redirect_Command
{
	CHAR	*Trigger;
	UCHAR	lTrigger;
	INT		(* Command)(LPEVENT_DATA, IO_STRING *);

} Redirect_Command;


//	Suggested flags for event
#define EVENT_BUFFER		0001	//	Output to buffer
#define EVENT_PREFIX		0002	//	Append prefix to output
#define EVENT_NEWLINE		0004	//	Use newlines
#define	EVENT_DETACH		0100
#define EVENT_DIRECT		0xF0000000
#define	EVENT_ERROR			0200
#define	EVENT_SILENT		0400	//	No output




typedef struct _REDIRECT
{
	IOOVERLAPPED		Overlapped;
	BOOL				bComplete;
	BOOL				bOutput;
	HANDLE				hPipe, hEvent;
	LPEVENT_DATA		lpEventData;
	TCHAR				pBuffer[16384];
	BUFFER				Output;
	DWORD				dwBuffer, dwOffset, dwLastError, dwCounter;

} REDIRECT, *LPREDIRECT;


typedef struct _TCLREDIRECT
{
	HANDLE				hEvent;
	LPEVENT_DATA		lpEventData;
	BUFFER				Output;
	DWORD				dwLastError;

} TCLREDIRECT, *LPTCLREDIRECT;


typedef struct _EVENT_COMMAND
{
	LPTSTR		tszCommand;
	LPTSTR		tszParameters;
	LPBUFFER	lpOutputBuffer;
	LPIOSOCKET	lpOutputSocket;
	LPTSTR		tszOutputPrefix;
	LPVOID		lpDataSource;
	DWORD		dwDataSource;

} EVENT_COMMAND, * LPEVENT_COMMAND;

BOOL RunEvent(LPEVENT_COMMAND lpCommandData);
VOID Redirect_SendSocket(LPREDIRECT_WAIT lpRedirect, DWORD dwBytesSent, DWORD dwLastError);
BOOL InstallEvent(LPSTR szName, LPVOID lpProc);
BOOL Event_Init(BOOL bFirstInitialization);
VOID Event_DeInit(VOID);
