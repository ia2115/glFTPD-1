typedef struct _FILECONTEXT
{
	LPVOID			lpData;
	DWORD			dwData;

} FILECONTEXT, * LPFILECONTEXT;

typedef struct _FSEARCH
{
	DWORD	dwFileAttributes;
	LPTSTR	tszFileName;

} FSEARCH, * LPFSEARCH;

typedef struct _FILEINFO
{
	LONG volatile	lReferenceCount;
	UINT64			FileSize;
	DWORD			dwSubDirectories;
	FILETIME		ftModificationTime;
	FILETIME		ftCreationTime;
	UINT32			Uid;
	UINT32			Gid;
	DWORD			dwFileMode;
	DWORD			dwFileAttributes;
	FILECONTEXT		Context;
	DWORD			dwFileName;
	TCHAR			tszFileName[1];

} FILEINFO, * LPFILEINFO;

typedef struct _DIRECTORYINFO
{
	LONG volatile		lReferenceCount;
	LPFILEINFO			*lpFileInfo;
	LPFILEINFO			lpRootEntry;
	DWORD				dwDirectorySize;

} DIRECTORYINFO, * LPDIRECTORYINFO;


typedef struct _DIRECTORYCACHEINFO
{
	LONG	lHits;
	LONG	lMisses;
	LONG	lFlushes;
	LONG	lCollisions;

} DIRECTORYCACHEINFO, *LPDIRECTORYCACHEINFO;


typedef struct _DIRECTORY
{
	struct _DIRECTORY	*lpPrev;
	struct _DIRECTORY	*lpNext;

	HANDLE				hEvent;
	BOOL				bPopulated;
	BOOL				bPermissions;
	BOOL				bForceUpdate;
	LONG 				lReferenceCount;
	FILETIME			ftCacheTime;
	LPDIRECTORYINFO		lpDirectoryInfo;
	UINT32				Hash;
	DWORD				dwFileName;
	TCHAR				tszFileName[1];	

} DIRECTORY, * LPDIRECTORY;

typedef struct _DIRECTORYTABLE
{
	LPDIRECTORY			*lpDirectory;
	DWORD				dwDirectories;
	DWORD				dwAllocated;
	LPDIRECTORY			lpDirectoryList[2];
	CRITICAL_SECTION	CriticalSection;

} DIRECTORYTABLE, * LPDIRECTORYTABLE;

typedef struct _VFSUPDATE
{
	UINT32		Uid;
	UINT32		Gid;
	DWORD		dwFileMode;
	FILECONTEXT	Context;

} VFSUPDATE, * LPVFSUPDATE;

typedef struct _FIND
{
	LPDIRECTORYINFO	lpDirectoryInfo;
	DWORD			dwOffset;
	TCHAR			tszFilter[1];

} FIND, *LPFIND;

typedef struct _DELETELIST
{
	struct _DELETELIST	*lpNext;
	DWORD			dwFileName;
	TCHAR			tszFileName[1];
} DELETELIST, *LPDELETELIST;


#define	FILE_ATTRIBUTE_IOFTPD	0x10000000
#define FILE_ATTRIBUTE_DIRTY	0x20000000


#define _I_READ		0002L
#define _I_WRITE	0004L
#define _I_EXECUTE	0001L
#define _I_OWN		1000L


#define S_IRWXU		0700
#define S_IRUSR		0400
#define S_IWUSR		0200
#define S_IXUSR		0100
#define S_IRWXG		0070
#define S_IRGRP		0040
#define S_IWGRP		0020
#define S_IXGRP		0010
#define S_IRWXO		0007
#define S_IROTH		0004
#define S_IWOTH		0002
#define S_IXOTH		0001

#define	PRIVATE			0
#define SYMBOLICLINK	1


BOOL DeleteFileContext(LPFILECONTEXT lpContext, BYTE Item);
BOOL FreeFileContext(LPFILECONTEXT lpContext);
LPVOID FindFileContext(BYTE Item, LPFILECONTEXT lpContext);
BOOL InsertFileContext(LPFILECONTEXT lpContext, BYTE Item, LPVOID lpData, DWORD dwData);
BOOL CreateFileContext(LPFILECONTEXT lpContext, LPFILECONTEXT lpSourceContext);

BOOL DirectoryCache_Init(BOOL bFirstInitialization);
VOID DirectoryCache_DeInit(VOID);


BOOL IoRemoveDirectory(LPTSTR tszPath);
BOOL MarkDirectory(LPTSTR tszFileName);
BOOL UpdateFileInfo(LPTSTR tszFileName, LPVFSUPDATE lpData);
BOOL GetFileInfo(LPTSTR tszFileName, LPFILEINFO *lpFileInfo);
VOID CloseFileInfo(LPFILEINFO lpFileInfo);
LPVOID IoFindFirstFile(LPTSTR tszPath, LPTSTR tszFilter, LPFILEINFO *lpFileInfo);
BOOL IoFindNextFile(LPVOID hFind, LPFILEINFO *lpResult);
VOID IoCloseFind(LPVOID hFind);
LPDIRECTORYINFO OpenDirectory(LPTSTR tszFileName, BOOL bRecursive);
BOOL CloseDirectory(LPDIRECTORYINFO lpDirectoryInfo);
BOOL Access(LPUSERFILE lpUserFile, LPFILEINFO lpFileInfo, DWORD dwMode);


extern UINT32 volatile DefaultUid[], DefaultGid[];
extern DWORD volatile dwDefaultFileMode[];