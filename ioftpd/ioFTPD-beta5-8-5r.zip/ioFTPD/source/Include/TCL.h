#define TCL_CMD		INT (__cdecl *)(LPVOID, Tcl_Interp *, INT, Tcl_Obj *const *)


BOOL TclExecute(LPEVENT_DATA lpEventData, IO_STRING *Arguments);
BOOL Tcl_ModuleInit(VOID);
VOID Tcl_ModuleDeInit(VOID);


#define TCL_USERFILE_OPEN	0001
#define TCL_USERFILE_LOCK	0002
#define TCL_GROUPFILE_OPEN	0010
#define TCL_GROUPFILE_LOCK	0020
#define TCL_MOUNTFILE_OPEN	0100

#define TCL_REALPATH		1
#define TCL_REALDATAPATH	2
#define TCL_VIRTUALPATH		3
#define TCL_VIRTUALDATAPATH	4
#define TCL_TRANSFEROFFSET	5
#define TCL_SPEED		6
#define TCL_STATUS		7
#define TCL_LOGINTIME		8
#define TCL_TIMEIDLE		9
#define TCL_HOSTNAME		10
#define TCL_IDENT		11
#define TCL_IP			12
#define TCL_UID			13
#define TCL_CLIENTID		14
#define TCL_ACTION			15

#define SPINLOCK			0
#define SEMAPHORE			1
#define EVENT				2
#define TCL_MAX_WAITOBJECTS		100

typedef struct _TCL_WAITOBJECT
{
	struct _TCL_WAITOBJECT	*lpNext;
	struct _TCL_WAITOBJECT	*lpPrev;
	LONG volatile			lReferenceCount;
	DWORD					dwType;
	LPVOID volatile			lpData;
	TCHAR					tszName[1];

} TCL_WAITOBJECT, *LPTCL_WAITOBJECT;

typedef struct _TCL_WHO
{
	DWORD	dwType[32];
	DWORD	dwCount;
	INT	iOffset;

} TCL_WHO, * LPTCL_WHO;


typedef struct _TCL_DATA
{
	DWORD			dwFlags;
	LPUSERFILE		lpUserFile;
	LPGROUPFILE		lpGroupFile;
	LPVOID			hMountFile;
	LPTCL_WAITOBJECT	lpWaitObject[TCL_MAX_WAITOBJECTS];
	DWORD			dwWaitObject;
	TCL_WHO			WhoData;

} TCL_DATA, * LPTCL_DATA;


typedef struct _TCL_VARIABLE
{
	LPVOID		lpTclVar;
	CHAR		szName[1];

} TCL_VARIABLE, * LPTCL_VARIABLE;



typedef struct _TCL_INTERPRETER
{
	LPVOID					lpInterp;
	LPEVENT_DATA			lpEventData;
	LPTCL_DATA				lpTclData;
	struct _TCL_INTERPRETER	*lpNext;

} TCL_INTERPRETER, * LPTCL_INTERPRETER;


typedef struct _TCL_INTERPRETERPOOL
{
	LPTCL_INTERPRETER	lpInterpreter;
	DWORD			dwSize;

} TCL_INTERPRETERPOOL, * LPTCL_INTERPRETERPOOL;



typedef struct _TCL_COMMAND
{
	LPSTR		szCommand;
	LPVOID		lpProc;

} TCL_COMMAND;

#ifdef _UNICODE
#define Tcl_GetTString Tcl_GetUnicode
#define Tcl_SetTStringObj Tcl_SetUnicodeObj
#else
#define Tcl_GetTString Tcl_GetString
#define Tcl_SetTStringObj Tcl_SetStringObj
#endif