/*

  USHORT	Type

  TYPE 0 (String):

  USHORT	Length
  CHAR		String

  TYPE 1 (End of line):
  TYPE 2 (End of line - no prefix to next line):

  TYPE 5 - 155

  UCHAR		Prefix Length
  CHAR      *Prefix
  UCHAR		Parameters

  USHORT	Length
  CHAR		*Parameter

  ...

  USHORT	Length N
  CHAR		*Parameter N


  TYPE 200 - 254

  UCHAR		Prefix Length
  CHAR		*Prefix

  TYPE 255 (EOF)

  */

#define STRING			0
#define NEWLINE			1
#define PREFIX			2
#define NOPREFIX		3
#define ZERO			4
#define	OBJECT			5
#define	VARIABLE		200
#define THEEND			255

#define	SERVICE_CONNECTIONS			1
#define	SERVICE_TRANSFERS			2
#define SERVICE_AVAILABILITY		3
#define SERVICE_TRANSFERED			4
#define SERVICE_WHO					5
#define SERVICE_USERS				6

#define	GROUP_DESCRIPTION	1
#define	GROUP_USERSLOTS		2
#define	GROUP_LEECHSLOTS	3
#define	GROUP_USERS			4
#define GROUP_MOUNTFILE		5


#define	CONVERT_INTEGER			0001L
#define CONVERT_SUFFIX			0002L
#define CONVERT_GROUPFILE		0004L
#define CONVERT_SERVICE			0400L
#define CONVERT_FILE			0100L
#define CONVERT_STATS			0200L
#define CONVERT_WHO				0010L

#define C_INTEGER				0
#define C_STRING				1
#define C_INTEGER_VARIABLE		2
#define C_STRING_VARIABLE		3
#define C_FLOAT_VARIABLE		4
#define C_UNKNOWN_VARIABLE		5
#define C_ARGS					0100000L


#define B_USER				0002L

#define B_COMMAND			000001L
#define B_DATA				000002L
#define B_USERFILE			000010L
#define B_GROUPFILE			000020L
#define B_CONNECTION		000100L
#define B_MOUNTTABLE		000000L
#define B_FILE				001000L
#define B_WHO				002000L
#define B_STATS				004000L
#define B_ANY				010000L


#define WHO_SPEED_CURRENT		2
#define WHO_SPEED_UPLOAD		3
#define WHO_SPEED_DOWNLOAD		4
#define WHO_SPEED_TOTAL			5
#define WHO_ACTION			6
#define WHO_FILESIZE			7
#define WHO_VIRTUALPATH			8
#define WHO_VIRTUALDATAPATH		9
#define WHO_PATH			10
#define WHO_DATAPATH			11
#define WHO_TRANSFERS_UPLOAD		12
#define WHO_TRANSFERS_DOWNLOAD		13
#define WHO_TRANSFERS_TOTAL		14
#define WHO_USERS_TOTAL			15
#define WHO_IDLERS_TOTAL		16
#define WHO_LOGIN_HOURS			17
#define WHO_LOGIN_MINUTES		18
#define WHO_LOGIN_SECONDS		19
#define WHO_IDLE_HOURS			20
#define WHO_IDLE_MINUTES		21
#define WHO_IDLE_SECONDS		22
#define WHO_HOSTNAME			23
#define WHO_IP				24
#define WHO_CONNECTION_ID		25
#define	WHO_IDENT			26
#define WHO_SERVICENAME			27

#define WHO_LEFT_ALIGN			1
#define WHO_RIGHT_ALIGN			2



#define DT_FTPUSER			1
#define DT_TELNETUSER		2
#define DT_USERFILE			3
#define DT_GROUPFILE		4
#define DT_STATS			5
#define DT_WHO				6




typedef struct _ARGUMENT_LIST
{

	BYTE					pBuffer[8];
	PCHAR					pArgument;
	DWORD					dwArgument;
	struct _ARGUMENT_LIST	*lpNext;

} ARGUMENT_LIST, * LPARGUMENT_LIST;





typedef struct _MESSAGEDATA
{
	LPSTR			szFormat;
	DWORD			dwFormat;

	LPVOID			lpData;
	DWORD			dwData;
	DATA_OFFSETS	DataOffsets;

	LPSTR			szPrefix[2];
	DWORD			dwPrefix[2];

	LPBUFFER		lpOutBuffer;

} MESSAGEDATA, * LPMESSAGEDATA;





typedef struct _MESSAGE_CACHE
{

	LPSTR			szFileName;
	DWORD			dwFileName;
	DWORD			dwCacheID;
	FILETIME		ftCacheTime;

	struct _MESSAGE_CACHE	*lpNext;
	struct _MESSAGE_CACHE	*lpPrev;

} MESSAGE_CACHE, * LPMESSAGE_CACHE;


typedef struct _ARG_PROC
{
	LPVOID				lpProc;
	struct _ARG_PROC	*lpNext;

} ARG_PROC, * LPARG_PROC;


typedef struct _MESSAGE_VARIABLE
{
	LPTSTR		tszName;
	DWORD		dwName;
	BOOL		bArgs;
	LPARG_PROC	lpArgProc;
	LPVOID		AllocProc;
	LPVOID		FreeProc;
	DWORD		dwRequiredData;
	DWORD		dwType;

} MESSAGE_VARIABLE, * LPMESSAGE_VARIABLE;



typedef struct _OBJV
{
	LPVOID	lpMemory;
	LPVOID	FreeProc;
	PBYTE	pValue;

} OBJV, * LPOBJV;



typedef struct _VARIABLE_MODULE
{
	LPSTR					szName;
	HMODULE					hModule;
	LPVOID					(* GetProc)(LPSTR);
	BOOL					(* InstallMessageVariable)(LPTSTR, LPVOID, LPVOID, DWORD, DWORD, ...);

	struct _VARIABLE_MODULE	*lpNext;

} VARIABLE_MODULE, *LPVARIABLE_MODULE;




BOOL Object_Get_Int(LPMESSAGEDATA lpData, LPOBJV lpObject, LPINT lpValue);
LPSTR Object_Get_String(LPMESSAGEDATA lpData, LPOBJV lpObject);
BOOL TextFile_Show(LPSTR szFileName, LPBUFFER lpOutBuffer, LPSTR szPrefix);
BOOL MessageFile_Show(LPSTR szFileName, LPBUFFER lpOutBuffer, LPVOID lpData, DWORD dwData, LPSTR szPrefix, LPSTR szLastPrefix);
BOOL Message_Compile(LPBYTE pBuffer, LPBUFFER lpOutBuffer, LPVOID lpData, DWORD dwData, LPSTR szPrefix, LPSTR szLastPrefix);
LPBYTE Message_PreCompile(PCHAR lpBuffer, LPDWORD lpOutSize);
LPBYTE Message_Load(LPSTR szFileName);
WORD FindMessageVariable(LPSTR szName, DWORD dwName, BOOL bArgs, LPBYTE lpType);
BOOL InstallMessageVariable(LPSTR szName, LPVOID lpAllocProc, LPVOID lpFreeProc, DWORD dwRequiredData, DWORD dwType, ...);
LPVOID GetVariable(WORD wIndex);

BOOL Message_Init(BOOL bFirstInitialization);
VOID Message_DeInit(VOID);
BOOL MessageObjects_Init(VOID);
BOOL MessageVariables_Init(VOID);
VOID MessageVariables_DeInit(VOID);




