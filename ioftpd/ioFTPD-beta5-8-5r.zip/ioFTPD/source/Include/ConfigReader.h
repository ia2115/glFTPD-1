typedef struct _CONFIG_LINE
{
	LPSTR				Variable;
	INT					Variable_l;
	LPSTR				Value;
	CHAR				Active;
	LPSTR				Text;
	INT					Value_l;
	INT					Row;
	struct _CONFIG_LINE	*Next;

} CONFIG_LINE, * LPCONFIG_LINE;


typedef struct _CONFIG_LINE_ARRAY
{
	LPSTR						Name;
	LPCONFIG_LINE				*Sorted;
	LPCONFIG_LINE				First_Line;
	INT							Name_Len;
	INT							Lines;
	INT							SSize;
	struct _CONFIG_LINE_ARRAY	*Next;

} CONFIG_LINE_ARRAY, * LPCONFIG_LINE_ARRAY;


#define CONFIG_INSERT	0
#define CONFIG_REPLACE	1
#define CONFIG_DEL		2



BOOL Config_Init(BOOL bFirstInitialization, LPVOID lpConfigFile);
VOID Config_DeInit(VOID);
VOID Config_Free(LPVOID lpArray);
BOOL Config_Write(VOID);
VOID Config_Lock(BOOL bExclusive);
VOID Config_Unlock(BOOL bExclusive);
LPSTR Config_Get(LPSTR szArray, LPSTR szVariable, LPSTR szBuffer, LPINT lpOffset);
LPSTR Config_Get_Path(LPSTR szArray, LPSTR szVariable, LPSTR szSuffix, LPSTR szBuffer);
LPSTR Config_Get_Linear(LPSTR szArray, LPSTR szVariable, LPSTR szBuffer, LPVOID *lpOffset);
BOOL Config_Get_Int(LPSTR szArray, LPSTR szVariable, LPINT lpValue);
BOOL Config_Get_Bool(LPSTR szArray, LPSTR szVariable, LPBOOL lpValue);
BOOL Config_Get_Permission(LPSTR szArray, LPSTR szVariable, LPUSERFILE lpUserFile);
BOOL PathCheck(LPUSERFILE lpUserFile, LPSTR szVirtualPath, LPSTR szAccessMethod);
VOID Config_Get_Section(LPSTR szVirtualPath, LPSTR szSection, LPINT lpCreditSection, LPINT lpStatsSection);
VOID Config_Print(LPBUFFER lpBuffer, LPSTR szArray, LPSTR szLinePrefix);
//	Unchecked
BOOL Config_Read(VOID);
BOOL Config_Set(LPSTR Array, INT Line, LPSTR Value, INT Mode);
