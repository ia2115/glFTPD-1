#include <wincrypt.h>
#include <wintrust.h>
#include <schannel.h>
#define SECURITY_WIN32
#include <security.h>
#include <sspi.h>



typedef struct _LINEBUFFER
{
	DWORD	dwSize, dwLength, dwOffset, dwSlack;
	PCHAR	pBuffer;
	BOOL	bOverflow;

} LINEBUFFER, *LPLINEBUFFER;




typedef struct _HANDSHAKE
{
	PBYTE		Buffer;
	UINT		s_Buffer;
	UINT		t_Buffer;
	SecBuffer	sbExtra;

} HANDSHAKE;

typedef struct _SHUTDOWN
{
	PBYTE		Buffer;
	UINT		s_Buffer;
	UINT		t_Buffer;

} SHUTDOWN;

typedef struct _SENDBUFFER
{
	DWORD		dwHeader;		//	Length of message header
	DWORD		dwEncrypted;	//	Length of encrypted data
	DWORD		dwTrailer;		//	Length of message trailer
	DWORD		dwSize;			//	Total size of message
	DWORD		dwLeft;			//	Bytes left from message
	DWORD		dwOriginal;		//	Original size of message
	BYTE		pBuffer[64];	//	Header&trailer buffer

} SENDBUFFER, * LPSENDBUFFER;



typedef struct _RECEIVEBUFFER
{
	DWORD		dwBuffer;			//	Amount of encrypted data in buffer
	DWORD		dwDecrypted;		//	Amount of decrypted data in buffer
	DWORD		dwDecryptedCopied;	//	Amount of decrypted data copied from buffer
	DWORD		dwSlack;			//	Amount of data between encrypted data and buffer begin
	DWORD		dwBufferSize;		//	Size of buffer
	PCHAR		pBuffer;			//	Buffer
	BOOL		bFirstRead;

} RECEIVEBUFFER, * LPRECEIVEBUFFER;



typedef struct _SECURITY
{
	PCredHandle					ph_Creds;
	SECURITY_STATUS				scRet;
	UINT						State;
	BOOL						fInitContext;
	//	Internal buffers
	HANDSHAKE					Handshake;
	SHUTDOWN					Shutdown;
	SENDBUFFER					SendBuffer;
	RECEIVEBUFFER				ReceiveBuffer;
	//	Additional information
	SecPkgContext_StreamSizes	Sizes;
	CtxtHandle					h_Context;

} * PSECURITY, SECURITY;


typedef struct _SOCKET_OPTIONS
{
	DWORD	dwReceiveLimit;
	DWORD	dwSendLimit;
	DWORD	dwPriority;
	DWORD	dwFlags;

} SOCKET_OPTIONS, SOCKET_OPTIONS;


typedef struct _IOSOCKET
{
	LONG volatile			Socket;
	SOCKETOVERLAPPED		Overlapped[2];
	DWORD					dwBandwidthLimit[2];
	SOCKET_OPTIONS			Options;
	PSECURITY				Secure;
	LPIODEVICE				lpDevice;
	LPLINEBUFFER			lpLineBuffer;

} IOSOCKET, * PIOSOCKET, * LPIOSOCKET;


typedef struct _LINETRANSFER
{
	LPIOSOCKET			lpSocket;
	DWORD				dwLastError;
	VOID				(* lpCallBack)(LPVOID, LPSTR, DWORD);
	LPVOID				lpContext;

} LINETRANSFER, *LPLINETRANSFER;


#define	SSL_HANDSHAKE_IN	0
#define SSL_HANDSHAKE_OUT	1
#define SSL_ACTIVE			2
#define SSL_CLOSE			3

#define SSL_ACCEPT			0001
#define SSL_CONNECT			0002
#define	SSL_LARGE_BUFFER	0100

#define	BIDIRECTIONAL	0001
#define	SECURE			0002

#define	RECEIVE_LIMIT			0
#define	SEND_LIMIT				1
#define SOCKET_PRIORITY			2
#define IO_SOCKET				298

#define	IsSecure(Socket)		(Socket.Options.dwFlags & SECURE)
#define IsActiveSecure(Socket)	((Socket.Options.dwFlags & SECURE) && Socket.Secure->State == SSL_ACTIVE)




typedef struct _IOBUFFER
{
	PCHAR	buf;
	DWORD	len, offset, size;
	DWORD	dwType, dwTimerType, dwTimeOut;
	BOOL	bProcessed, bAllocated;
	union
	{
		struct
		{
			LPIOFILE	Handle;
			DWORD		dwInternal;
		} File;
		LPDWORD		lpBytesReceived;
//		LPIOPIPE	hPipe;
	};

} IOBUFFER, * LPIOBUFFER;

typedef struct _TRANSFERRATE
{
	DWORD			dwBytesTransfered;
	DWORD			dwTickCount;
	VOID			(*lpCallBack)(LPVOID, DWORD, DWORD);

} TRANSFERRATE, * LPTRANSFERRATE;

typedef struct _PACKAGETRANSFER
{
	LPIOSOCKET			lpSocket;
	LPVOID				hTimer;
	LPIOBUFFER			lpBuffer;
	DWORD				dwBuffer;
	DWORD				dwLastError;
	LPTRANSFERRATE		lpTransferRate;
//	LPCRITICAL_SECTION	lpCriticalSection;
//	SOCKETOVERLAPPED	SocketOverlapped[1];
//	FILEOVERLAPPED		FileOverlapped[1];
	DWORD volatile		dwTime;
	VOID				(* lpCallBack)(LPVOID, DWORD);
	LPVOID				lpContext;

} PACKAGETRANSFER, *LPPACKAGETRANSFER;

#define PACKAGE_BUFFER_SEND	1
#define PACKAGE_FILE_SEND	2
#define PACKAGE_FILE_RECEIVE	3
#define PACKAGE_SSL_ACCEPT	4
#define PACKAGE_SSL_CLOSE	5
#define PACKAGE_SHUTDOWN	6
#define PACKAGE_LINE_RECEIVE	7
#define PACKAGE_BUFFER_RECEIVE	8

#define NO_TIMER		0
#define TIMER_PER_TRANSMIT	1
#define TIMER_PER_PACKAGE	2



extern HANDLE	hCompletionPort;

//	Initialization routines
BOOL Socket_Init(BOOL bFirstInitialization);
VOID Socket_DeInit(VOID);
BOOL Security_Init(BOOL bFirstInitialization);
VOID Security_DeInit(VOID);
//	Tcp socket api
INT Receive(LPIOSOCKET lpSocket, PCHAR pBuffer, DWORD dwBuffer);
INT Send(LPIOSOCKET lpSocket, PCHAR pBuffer, DWORD dwBuffer);
BOOL SetSocketOption(LPIOSOCKET lpSocket, INT iLevel, INT iOptionName, LPVOID lpValue, INT iValue);
BOOL ReceiveOverlapped(LPIOSOCKET lpSocket, LPSOCKETOVERLAPPED lpOverlapped);
BOOL SendOverlapped(LPIOSOCKET lpSocket, LPSOCKETOVERLAPPED lpOverlapped);
BOOL SendQueuedIO(LPSOCKETOVERLAPPED lpOverlapped);
BOOL ReceiveQueuedIO(LPSOCKETOVERLAPPED lpOverlapped);
INT ioSend(LPIOSOCKET lpSocket, PCHAR pBuffer, INT dwBuffer);
INT ioRecv(LPIOSOCKET lpSocket, PCHAR pBuffer, INT dwBuffer);
DWORD FlushLineBuffer(LPIOSOCKET lpSocket, LPVOID lpBuffer, DWORD dwBuffer);
BOOL CloseSocket(LPIOSOCKET lpSocket, BOOL bNoLinger);
VOID ioCloseSocket(LPIOSOCKET lpSocket, BOOL bNoLinger);
VOID SetOverlappedFunction(LPIOOVERLAPPED lpOverlapped, LPVOID lpProc, LPVOID lpContext);
VOID GetOverlappedFunction(LPIOOVERLAPPED lpOverlapped, LPVOID lpProc, LPVOID lpContext);
//	Secure socket api
VOID EncryptSocketBuffer(LPSOCKETOVERLAPPED lpOverlapped);
VOID DecryptSocketBuffer(LPSOCKETOVERLAPPED lpOverlapped);
BOOL Secure_Init_Socket(LPIOSOCKET lpSocket, LPIOSERVICE lpService, DWORD dwCreationFlags);
BOOL Secure_Load_Credentials(LPSTR CertificateName, DWORD dwProtocol, DWORD dwMinimumCipherStrength, DWORD dwMaximumCipherStrength, LPVOID ServerCredentials);
INT Secure_AcceptEx(LPIOSOCKET lpSocket, DWORD dwBytesTransfered);
INT Secure_Close(LPIOSOCKET lpSocket, DWORD dwBytesTransfered);
DWORD Secure_ReceiveResult(LPIOSOCKET lpSocket, LPVOID lpBuffer, DWORD dwBufferSize, DWORD dwBytesReceived);
DWORD Secure_SendResult(LPIOSOCKET lpSocket, DWORD dwBytesSent);
//	Hostname handling
BOOL BindSocket(SOCKET Socket, ULONG lAddress, USHORT sPort, BOOL bReuse);
BOOL BindSocketToDevice(LPIOSERVICE lpService, LPIOSOCKET lpSocket, PULONG pNetworkAddress, PUSHORT pPort, DWORD dwFlags);
VOID UnbindSocket(LPIOSOCKET lpSocket);
ULONG HostToAddress(LPSTR szHostName);
//	Socket scheduling
UINT WINAPI SocketSchedulerThread(LPVOID lpNull);
VOID UnregisterSchedulerDevice(LPIODEVICE lpDevice);
VOID RegisterSchedulerDevice(LPIODEVICE lpDevice);
//	Asynchronous message based functions notification
LPVOID WSAAsyncSelectWithTimeout(SOCKET Socket, DWORD dwTimeOut, DWORD dwFlags, LPDWORD lpResult);
BOOL WSAAsyncSelectCancel(LPVOID lpEvent);
BOOL WSAAsyncSelectContinue(LPVOID lpEvent, LPVOID lpProc, LPVOID lpContext);

VOID ReceiveLine(LPIOSOCKET lpSocket, DWORD dwLineLength, VOID (* lpCallBack)(LPVOID, LPSTR, DWORD), LPVOID lpContext);
//	Transmit package API
BOOL TransmitPackage_Init(BOOL bFirstInitialization);
VOID TransmitPackage_DeInit(VOID);
VOID TransmitPackages(LPIOSOCKET lpSocket, LPIOBUFFER lpBuffer, DWORD dwBuffer, VOID (* lpTransferRateCallBack)(LPVOID, DWORD, DWORD), VOID (* lpCallBack)(LPVOID, DWORD), LPVOID lpContext);
//	MsWsock extensions
extern LPFN_ACCEPTEX				Accept;
extern LPFN_GETACCEPTEXSOCKADDRS	GetAcceptSockAddrs;


