typedef struct _CONNECTION_INFO
{
	struct sockaddr_in	ClientAddress;
	struct sockaddr_in	LocalAddress;
	LPSTR				szIdent;
	LPSTR				szHostName;
	UINT				uLoginAttempt;
	time_t				tLogin;
	LPIOSERVICE			lpService;
	DWORD				dwStatus;
	DWORD				dwUniqueId;
	LPVOID				lpHostInfo;

} CONNECTION_INFO, * PCONNECTION_INFO;