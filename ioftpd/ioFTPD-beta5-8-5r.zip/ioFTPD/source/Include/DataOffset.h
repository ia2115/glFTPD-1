
typedef struct _DATA_OFFSETS
{
	LPVOID				lpBuffer;
	DWORD				dwHave;
	DWORD				dwOffsetType;

	LPUSERFILE			lpUserFile;
	LPGROUPFILE			lpGroupFile;
	INT					iPosition;
	INT					iCreditSection;
	INT					iStatsSection;
	PCONNECTION_INFO	pConnectionInfo;
	LPCOMMAND			lpCommandChannel;
	LPDATACHANNEL		lpDataChannel;
	LPVOID				hMountTable;

	//	Unknown data
	LPVOID				lpUnknown;

} DATA_OFFSETS, * LPDATA_OFFSETS;

typedef struct _DATA_OFFSET
{
	LPDWORD	lpOffset;
	BOOL	(* ConditionFunc)(LPVOID);
	BYTE	bConditionParam;
	DWORD	dwHave[2];

} DATA_OFFSET;



#define	DATA_CONNECTION		pConnectionInfo
#define	DATA_USERFILE		lpUserFile
#define	DATA_GROUPFILE		lpGroupFile
#define DATA_CCHANNEL		lpCommandChannel
#define DATA_DCHANNEL		lpDataChannel
#define	DATA_CSECTION		iCreditSection
#define	DATA_SSECTION		iStatsSection
#define	DATA_POSITION		lpUnknown
#define	DATA_WHO			lpUnknown
#define	DATA_FILEINFO		lpUnknown
#define	DATA_MOUNTTABLE		lpMountTable



#define	HASDATAEX(x, y)		(x.dwHave & y)
#define	GETOFFSET(x, y)		(x.y)

VOID InitDataOffsets(LPDATA_OFFSETS lpDataOffsets, LPVOID lpBuffer, DWORD dwOffsetType);
