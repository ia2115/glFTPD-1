typedef struct _USER_MODULE
{
	//	These items are filled by ioftpd
	LPSTR	tszModuleFileName;
	HANDLE	hModule;

	INT32	(* Register)(LPVOID, LPTSTR, LPUSERFILE);	//	Register user to database
	BOOL	(* RegisterAs)(LPVOID, LPTSTR, LPTSTR);		//	Register user x as user y (rename :p)
	BOOL		(* Unregister)(LPVOID, LPSTR);				//	Unregister user from database
	BOOL	(* Update)(LPUSERFILE);						//	Update user in memory database
	LPVOID	(* GetProc)(LPTSTR);

	struct _USER_MODULE	*lpNext;

	//	These items are filled by module
	LPSTR	tszModuleName;

	BOOL	(* DeInitialize)(VOID);
	INT32	(* Create)(LPTSTR);				//	Create user
	BOOL	(* Delete)(LPTSTR, INT32);			//	Delete user
	BOOL	(* Rename)(LPTSTR, INT32, LPSTR);		//	Rename user
	BOOL	(* Lock)(LPUSERFILE);			//	Lock user, exclusive
	BOOL	(* Write)(LPUSERFILE);			//	Write user
	INT		(* Open)(LPTSTR, LPUSERFILE);	//	Open & read user
	BOOL	(* Close)(LPUSERFILE);
	BOOL	(* Unlock)(LPUSERFILE);			//	Unlock user

} USER_MODULE, * LPUSER_MODULE;


typedef struct _PARENT_USERFILE
{
	INT					Uid;	//	User id
	DWORD				dwErrorFlags;	//	Pending error flags
	LPVOID				lpTimer;	//	Pointer to timer
	LPUSER_MODULE		lpModule;		//	Pointer to module
	LPUSERFILE			lpUserFile;	//	Current shared userfile
	HANDLE				hPrimaryLock;	//	Primary lock, used for exclusive locking
	DWORD				dwLoginCount[3];	//	Login counters (by service type)
	LONG volatile		lOpenCount;		//	Usage counter
	LONG volatile		lSecondaryLock;		//	Secodary lock, used for shared locking

} PARENT_USERFILE, * LPPARENT_USERFILE;


typedef struct _USERFILE_CONTEXT
{
	HANDLE		hFileHandle;

} USERFILE_CONTEXT, * LPUSERFILE_CONTEXT;


typedef struct _USERSEARCH_NAME
{
	LPTSTR					tszName;
	struct _USERSEARCH_NAME	*lpNext;
	
} USERSEARCH_NAME, * LPUSERSEARCH_NAME;


typedef struct _USERSEARCH_ID
{
	INT32					Id;
	struct _USERSEARCH_ID	*lpNext;

} USERSEARCH_ID, * LPUSERSEARCH_ID;


typedef struct _USERSEARCH
{
	LPUSERSEARCH_NAME	lpIncludedUserName;
	LPUSERSEARCH_NAME	lpExcludedUserName;
	LPUSERSEARCH_ID		lpIncludedUserId;
	LPUSERSEARCH_ID		lpExcludedUserId;
	LPUSERSEARCH_ID		lpIncludedGroupId;
	LPUSERSEARCH_ID		lpExcludedGroupId;
	PINT32				lpIdList;
	DWORD				dwIdList;
	DWORD				dwOffset;

} USERSEARCH, * LPUSERSEARCH;


#define	UM_SUCCESS	0
#define	UM_ERROR	1
#define	UM_DELETED	2
#define UM_FATAL	3
#define INVALID_USER	(UINT32)-1

#ifndef WRITE_ERROR
#define STATIC_SOURCE	0001
#define	NO_SYNC		0002
#define	WRITE_ERROR	0001
#define	WAIT_UNREGISTER	0002
#endif


BOOL User_Init(BOOL bFirstInitialization);
VOID User_DeInit(VOID);
PINT32 GetUsers(LPDWORD lpUserIdCount);
INT32 User2Uid(LPSTR szUserName);
LPSTR Uid2User(INT32 Uid);
BOOL UserFile2Ascii(LPBUFFER lpBuffer, LPUSERFILE lpUserFile);
BOOL Ascii2UserFile(PCHAR pBuffer, DWORD dwBuffer, LPUSERFILE lpUserFile);
BOOL CreateUser(LPSTR szUserName);
BOOL DeleteUser(LPSTR szUserName);
BOOL RenameUser(LPSTR szUserName, LPSTR szNewUserName);
BOOL UserFile_Sync(LPUSERFILE *lpUserFile);
BOOL UserFile_Lock(LPUSERFILE *lpUserFile, DWORD dwFlags);
BOOL UserFile_WriteTimer(LPPARENT_USERFILE lpParentUserFile, LPTIMER lpTimer);
BOOL UserFile_Unlock(LPUSERFILE *lpUserFile, DWORD dwFlags);
BOOL UserFile_Close(LPUSERFILE *lpUserFile, DWORD dwOpenFlags);
BOOL UserFile_OpenPrimitive(INT32 Uid, LPUSERFILE *lpUserFile, DWORD dwOpenFlags);
BOOL UserFile_Open(LPSTR szUserName, LPUSERFILE *lpUserFile, DWORD dwOpenFlags);
LPVOID FindFirstUser(LPSTR szWildCard, LPUSERFILE *lpUserFile);
BOOL FindNextUser(LPVOID hUserSearch, LPUSERFILE *lpUserFile);
VOID HashString(LPSTR szString, PUCHAR pHash);
BOOL User_IsAdmin(LPUSERFILE lpAdmin, LPUSERFILE lpUserFile, PINT32 pGid);
DWORD UserFile_GetLoginCount(LPUSERFILE lpUserFile, DWORD dwType);
VOID UserFile_IncrementLoginCount(LPUSERFILE lpUserFile, DWORD dwType);
VOID UserFile_DecrementLoginCount(LPUSERFILE lpUserFile, DWORD dwType);

//	Default group module initialization routine
BOOL User_StandardInit(LPUSER_MODULE lpModule);
