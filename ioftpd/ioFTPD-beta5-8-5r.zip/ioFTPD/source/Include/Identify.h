typedef struct _CLASS
{
	LONG			lMaxClients;
	DWORD			dwClients;
	struct _CLASS	*lpNext;
	TCHAR			tszName[1];

} CLASS, * LPCLASS;


typedef struct _RULE
{
	DWORD			dwType;
	LPVOID			lpContext;
	DWORD			dwContext;
	struct _RULE	*lpNext;

} RULE, * LPRULE;

typedef struct _ACCEPT_RULE
{
	DWORD		dwType;
	LPVOID		lpContext;
	DWORD		dwContext;
	LPRULE		lpNext;

	LONG		lConnectionsPerHost;
	LPCLASS		lpClass;

} ACCEPT_RULE, * LPACCEPT_RULE;


typedef struct _DENY_RULE
{
	DWORD		dwType;
	LPVOID		lpContext;
	DWORD		dwContext;
	LPRULE		lpNext;

	LPTSTR		tszLog;

} DENY_RULE, * LPDENY_RULE;


typedef struct _HOSTCLASS
{
	LPCLASS	lpClass;
	LONG	lConnectionsPerHost;
	DWORD	dwClassListId;

} HOSTCLASS, *LPHOSTCLASS;


typedef struct _BANINFO
{
	DWORD			dwBanDuration;
	BYTE			pNetworkAddress[8];
	DWORD			dwNetworkAddress;
	DWORD			dwConnectionAttempts;
	struct _BANINFO	*lpNext;

} BANINFO, *LPBANINFO;


#define	ACCEPT		0001
#define	DENY		0002
#define	HOSTNAME	0010
#define	IP			0020



typedef struct _HOSTINFO
{
	BYTE			NetworkAddress[8];
	DWORD			dwNetworkAddress;
	LPSTR			szHostName;
	DWORD			dwHostNameCacheTime;
	LPSTR			szIdent;
	DWORD			dwIdentCacheTime;
	DWORD			dwLastOccurance;
	DWORD			dwTickCount;
	DWORD			dwShareCount;
	DWORD			dwClients;
	HOSTCLASS		ClassInfo;
	LONG volatile	lLock;

	struct _HOSTINFO	*lpNext;	//	Also used as resolve queue
	struct _HOSTINFO	*lpPrev;	//	Also used as ident reading queue

} HOSTINFO, * LPHOSTINFO;


typedef struct _IDENTCLIENT
{
	IOSOCKET	Socket;
	CHAR		pBuffer[256];
	LPSTR		szIdentReply;
	LPVOID		hTimer;
	DWORD		dwBuffer;
	DWORD		dwLastError;
	DWORD		dwClientId;
	WORD		wServerPort, wClientPort;
//	WORD		wClientPort;
//	BOOL		bSend;
	LPHOSTINFO	lpHostInfo;

} IDENTCLIENT, * LPIDENTCLIENT;


typedef struct _RESOLVE
{
	LPHOSTINFO	lpHostInfo;
	struct _RESOLVE	*lpNext;

} RESOLVE, * LPRESOLVE;

LPBANINFO GetNetworkBans(VOID);
VOID UnbanNetworkAddress(PBYTE pNetworkAddress, DWORD dwNetworkAddress);
DWORD GetCurrentClassListId(VOID);
VOID GetHostClass(LPSTR szHostName, ULONG lNetworkAddress, LPHOSTCLASS lpHostClass);
BOOL IdentifyClient(LPNEWCLIENT lpNewClient);
BOOL Identify_Init(BOOL bFirstInitialization);
LPVOID RegisterNetworkAddress(PBYTE pNetworkAddress, DWORD dwNetworkAddress);
VOID UnregisterNetworkAddress(LPVOID lpHostInfo, DWORD dwCount);
VOID Identify_DeInit(VOID);
