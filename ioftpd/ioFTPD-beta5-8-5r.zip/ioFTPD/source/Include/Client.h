typedef struct _CLIENTSLOT
{
	DWORD				dwId;
	LONG volatile		lJobLock;
	LONG volatile		lDataLock;
	struct _CLIENTSLOT	*lpNext;

} CLIENTSLOT, * LPCLIENTSLOT;



typedef struct _CLIENT
{
	ONLINEDATA		Static;
	LPIOSERVICE		lpService;

	DWORD			dwJobFilter;
	LPCLIENTJOB		lpJobList;
	LPCLIENTJOB		lpActiveJobList;

	LPCLIENTJOB		lpActiveJob;
	LPCLIENTJOB		lpJobQueue[2];
	DWORD			dwActiveFlags;

	//	Synchronization items
	LPCLASS			lpClass;
	LPHOSTINFO		lpHostInfo;
	LPVOID			lpMemory;
	

} CLIENT, * LPCLIENT;


#define	DATA_TRANSFER			1000
#define	DATA_AUTHENTICATE		1001
#define	DATA_CHDIR				1002
#define	DATA_ACTION				1003
#define	DATA_TRANSFER_UPDATE	1004
#define	DATA_IDENT				1005

VOID ShowJobList(LPCSTR Prefix, LPBUFFER lpBuffer);
LRESULT SeekOnlineData(LPVOID lpBuffer, DWORD dwClientId);
LRESULT	GetOnlineData(LPVOID lpBuffer, DWORD dwClientId);
LRESULT KickUser(INT Uid);
LRESULT KillUser(UINT32 dwClientId);
LRESULT	ReleasePath(LPTSTR RealPath, LPTSTR VirtualPath);
VOID KillService(LPIOSERVICE lpService);

LPCLIENT LockClient(DWORD dwClientId);
VOID UnlockClient(DWORD dwClientId);
DWORD RegisterClient(PCONNECTION_INFO pConnectionInfo, LPVOID lpMemory);
VOID UnregisterClient(DWORD dwClientId, LPUSERFILE lpUserFile);
BOOL UpdateClientData(DWORD dwDataType, DWORD dwClientId, ...);
BOOL Client_Init(BOOL bFirstInitialization);
VOID Client_DeInit(VOID);

LONG volatile *GetClientTransferData(DWORD hClient);