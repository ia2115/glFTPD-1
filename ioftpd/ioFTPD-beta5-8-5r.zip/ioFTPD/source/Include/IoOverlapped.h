//	Used with file routines
typedef struct _FILEOVERLAPPED
{
	ULONG_PTR	Internal;
	ULONG_PTR	InternalHigh;
	DWORD		Offset;
	DWORD		OffsetHigh;
	HANDLE		hEvent;

	VOID	(* lpProc)(LPVOID, DWORD, DWORD);
	LPVOID		lpNext;
	LPVOID	lpContext;
	//	File specific information
	DWORD		dwCommand;
	LPVOID		lpBuffer;
	DWORD		dwBuffer;
	DWORD		Crc32;
	LPVOID		hFile;

} FILEOVERLAPPED, *LPFILEOVERLAPPED;

typedef struct _SOCKETOVERLAPPED
{
	ULONG_PTR	Internal;
	ULONG_PTR	InternalHigh;
	DWORD		Offset;
	DWORD		OffsetHigh;
	HANDLE		hEvent;

	VOID	(* lpProc)(LPVOID, DWORD, DWORD);
	LPVOID		lpNext;
	LPVOID	lpContext;
	//	Socket specific information
	WSABUF		Buffer[5];
	DWORD		dwBuffers;
	LPVOID		hSocket;

} SOCKETOVERLAPPED, *LPSOCKETOVERLAPPED;


typedef struct _IOOVERLAPPED
{
	ULONG_PTR	Internal;
	ULONG_PTR	InternalHigh;
	DWORD		Offset;
	DWORD		OffsetHigh;
	HANDLE		hEvent;

	VOID	(* lpProc)(LPVOID, DWORD, DWORD);
	LPVOID	lpNext;
	LPVOID	lpContext;

} IOOVERLAPPED, *LPIOOVERLAPPED;