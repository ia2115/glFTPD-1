typedef struct _TIME_STRUCT {

	INT64	i64TickCount;

} TIME_STRUCT, * LPTIME_STRUCT;


DOUBLE Time_Difference(LPTIME_STRUCT lpStartTime, LPTIME_STRUCT lpStopTime);
VOID Time_Read(LPTIME_STRUCT lpTime);
INT Time_Compare(LPTIME_STRUCT lpStartTime, LPTIME_STRUCT lpStopTime);
DWORD Time_DifferenceDW32(DWORD dwStart, DWORD dwStop);
VOID SystemTimeToLocalTime(LPSYSTEMTIME lpUniversalTime, LPSYSTEMTIME lpLocalTime);
BOOL Time_Init(BOOL bFirstInitialization);