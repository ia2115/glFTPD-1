typedef struct _FTP_VARIABLES
{
	LPSTR	szRenameFrom;

} FTP_VARIABLES;



typedef struct _FTP_USER
{
	CONNECTION_INFO		Connection;		//	Connection info
	LPUSERFILE			UserFile;		//	Userfile
	COMMAND				CommandChannel;	//	CommandChannel
	FTP_DATA			DataChannel;	//	FTP DataChannel
	LPVOID				hMountFile;		//	Handle to mount file
	FTP_VARIABLES		FtpVariables;	//	Ftp Variables

} FTP_USER, FTPUSER, * LPFTPUSER;



typedef struct _FTPCOMMAND
{
	LPTSTR	tszName;
	DWORD	dwFlags;
	LONG	lArgMin;
	LONG	lArgMax;
	BOOL	(*lpProc)(LPFTPUSER, LPIO_STRING);

} FTPCOMMAND, * LPFTPCOMMAND;



struct _cmd_table
{
	PCHAR	trigger;
	CHAR	trigger_len;
	CHAR	cmd_type;

	INT		min_argc;
	INT		max_argc;

   	BOOL	(*cmd) (LPFTPUSER, LPIO_STRING);
};



typedef struct _FTP_SETTINGS
{
	DWORD volatile	dwSocketBuffer[2];
	DWORD volatile	dwDataSocketBuffer[2];
	DWORD volatile	dwTransferBuffer;
	DWORD volatile	dwIdleTimeOut;
	DWORD volatile	dwLoginTimeOut;
	DWORD volatile	dwLoginAttempts;
	BOOL volatile	bTransmitFile;
	BOOL volatile	bNagle;

} FTP_SETTINGS, * LPFTP_SETTINGS;



BOOL FTP_Init(BOOL bFirstInitialization);
BOOL FTP_New_Client(PCONNECTION_INFO lpConnection);
BOOL FTP_Close_Connection(LPFTPUSER lpUser);
VOID FTP_WriteSocket(LPFTPUSER lpUser, DWORD dwBytesWritten, DWORD dwLastError);
VOID FTP_ReadSocket(LPFTPUSER lpUser, DWORD dwBytesRead, DWORD dwLastError);
VOID FTP_SecureAccept(LPFTPUSER lpUser, DWORD dwBytesTransfered, DWORD dwLastError);
BOOL FTP_ContinueSecure(LPFTPUSER lpUser);
BOOL FTP_ContinueRead(LPFTPUSER lpUser);
BOOL FTP_ContinueWrite(LPFTPUSER lpUser);