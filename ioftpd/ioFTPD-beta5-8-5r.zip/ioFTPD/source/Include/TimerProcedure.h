typedef struct _TIMERPROCEDURE
{
	DWORD					dwMinId;
	DWORD					dwMaxId;
	LRESULT					(* Proc)(WPARAM, LPARAM);

	struct _TIMERPROCEDURE	*pNext;

} TIMERPROCEDURE, * PTIMERPROCEDURE;