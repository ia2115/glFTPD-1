typedef struct _DEVICEINFO
{
	CRITICAL_SECTION	CriticalSection;
	DWORD				dwRequests;
	LPFILEOVERLAPPED	lpQueueHead;
	LPFILEOVERLAPPED	lpQueueTail;

} DEVICEINFO, * LPDEVICEINFO;


typedef struct _IOFILE
{
	HANDLE			FileHandle;
	FILEOVERLAPPED	Overlapped;
	DWORD			dwFlags;
	LPDEVICEINFO	lpDeviceInformation;

} IOFILE, * LPIOFILE;


typedef struct _DOWNLOAD
{
	PVIRTUALPATH	lpCurrentPath;
	LPIOFILE		lpFile;
	LPSTR			szNewPath;
	PVIRTUALPATH	lpDownloadPath;
	LPUSERFILE		lpUserFile;
	LPVOID			hMountFile;

} DOWNLOAD, * LPDOWNLOAD;


#define	FILE_READ			0
#define	FILE_WRITE			1
#define OVERLAPPED_INC(O, I) if ((O.Offset += I) < I) O.OffsetHigh++;


BOOL ioOpenFile(LPIOFILE lpFile, LPTSTR FileName,
				DWORD dwDesiredAccess, DWORD dwShareMode, DWORD dwCreationDisposition);
BOOL ioCloseFile(LPIOFILE lpFile);
BOOL ioSeekFile(LPIOFILE lpFile, LPDWORD lpSeekOffset, BOOL bSetEndOfFile);
DWORD ioGetFileSize(LPIOFILE lpFile, LPDWORD lpFileSizeHigh);
BOOL BindCompletionPort(HANDLE Handle);
BOOL DownloadFile(LPDOWNLOAD lpDownload);

BOOL File_Init(BOOL bFirstInitialization);
VOID File_DeInit(VOID);
VOID PopIOQueue(LPVOID hFile);
VOID IoReadFile(LPIOFILE lpFile, LPVOID lpBuffer, DWORD dwBufferSize);
VOID IoWriteFile(LPIOFILE lpFile, LPVOID lpBuffer, DWORD dwBufferSize);


