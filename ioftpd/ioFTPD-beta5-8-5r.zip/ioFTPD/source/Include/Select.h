typedef struct _SELECT
{
	LPVOID			lpProc;
	LPVOID			lpContext;
	LPDWORD			lpResult;
	DWORD			dwResult;
	DWORD			dwFlags;
	SOCKET			Socket;
	LPVOID			lpTimer;
	LONG volatile	lLock;
	struct _SELECT	*pNext;
	struct _SELECT	*pPrevious;

} SELECT, * PSELECT;