#define	TYPE_DIRECTORY	0001L
#define TYPE_FILE		0002L
#define	EXISTS			0100L
#define	RANDOM_DISK		0010L
#define	BEST_DISK		0020L
#define	TYPE_LINK		0004L



typedef struct _MOUNT_ITEM
{

	LPSTR	szFileName;
	DWORD	dwFileName;

} MOUNT_ITEM, * LPMOUNT_ITEM;



typedef struct _MOUNT_POINT
{

	LPSTR		szName;
	DWORD		dwName;

	MOUNT_ITEM	lpSubMount[MAX_SUBMOUNTS];
	DWORD		dwSubMounts;

	LPVOID		lpNextTable;

} MOUNT_POINT, * LPMOUNT_POINT;


typedef struct _MOUNT_TABLE
{
	LPMOUNT_POINT	*lpMountPoints;
	DWORD			dwMountPoints;
	DWORD			dwMountPointsAllocated;

} MOUNT_TABLE, * LPMOUNT_TABLE;


typedef struct _MOUNT_DATA
{
	LPMOUNT_POINT	Resume;
	INT				Last;
	DWORD			dwLastPath;
	LPSTR			Pwd;
	INT				Length;
	BOOL			Initialised;

} MOUNT_DATA;



typedef struct _PWD
{
	CHAR	pwd[_MAX_PWD];
	DWORD	len;
	LPSTR	RealPath;
	DWORD	l_RealPath;

	CHAR	SectionName[64 + 1];	// MAX_NAME + 1
	INT		StatsSection;
	INT		CreditSection;

} PWD, * PPWD, * PVIRTUALPATH, VIRTUALPATH;


typedef struct _MOUNTCACHEDATA
{
	LPMOUNT_TABLE		lpMountTable;
	LONG volatile		lShareCount;

} MOUNTCACHEDATA, * LPMOUNTCACHEDATA;

typedef struct _MOUNTCACHE
{
	LPMOUNTCACHEDATA	lpCacheData;
	LPSTR				szFileName;
	FILETIME			ftCacheTime;

} MOUNTCACHE, * LPMOUNTCACHE;


//	Function prototypes
VOID MountFile_DeInit(VOID);
BOOL MountFile_Init(BOOL bFirstInitialization);
VOID MountFile_Close(LPVOID hMountFile);
LPVOID MountFile_Open(LPSTR szFileName);

BOOL PWD_Copy(PVIRTUALPATH Source, PVIRTUALPATH Target, BOOL AllocatePath);
VOID PWD_Free(PVIRTUALPATH VirtualPath);
VOID PWD_Reset(PVIRTUALPATH VirtualPath);
LPSTR PWD_CWD(LPUSERFILE lpUserFile, PVIRTUALPATH Pwd, LPSTR ChangeTo, LPVOID hMountFile, DWORD dwFlags);
LPSTR PWD_Resolve(LPSTR szVirtualPath, LPVOID hMountFile, MOUNT_DATA *Data, BOOL Exists, INT ExtraMem);
LPMOUNT_TABLE PWD_GetTable(LPSTR szVirtualPath, LPVOID hMountFile);
