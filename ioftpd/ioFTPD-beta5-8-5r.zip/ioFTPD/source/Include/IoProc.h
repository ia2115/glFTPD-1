typedef struct _IOPROC
{
	LPSTR	szName;
	LPVOID	lpProc;

} IOPROC, * LPIOPROC;

VOID IoProc_DeInit(VOID);
BOOL IoProc_Init(BOOL bFirstInitialization);
LPVOID GetProc(LPSTR szName);
