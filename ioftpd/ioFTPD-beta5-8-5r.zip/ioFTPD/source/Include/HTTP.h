/*
403 Forbidden
404 Not found
405 Method Not Allowed
406 Not Acceptable
410 Gone
411 Length Required
500 Internal Server Error
501 Not Implemented
502 Bad Gateway
503 Service Unavailable
505 HTTP Version not supported*/


#define HTTP_FATAL			(DWORD)-1
#define HTTP_CONTINUE			100
#define	HTTP_OK				200
#define HTTP_BAD_REQUEST			400
#define HTTP_AUTHORIZE			401
#define HTTP_FORBIDDEN				403
#define HTTP_NOT_FOUND				404
#define HTTP_METHOD_NOT_ALLOWED		405
#define HTTP_NOT_ACCEPTABLE			406
#define HTTP_GONE					410
#define HTTP_LENGTH_REQUIRED		411
#define HTTP_INTERNAL_SERVER_ERROR	500
#define HTTP_NOT_IMPLEMENTED		501
#define HTTP_BAD_GATEWAY			502
#define HTTP_SERVICE_UNAVAILABLE	503
#define HTTP_INVALID_VERSION		505


#define HEADER_INVALID	0
#define HEADER_FATAL	1
#define HEADER_CONTINUE	2
#define HEADER_END		3

//	Request types
#define REQUEST_UNDEFINED	0
#define REQUEST_GET			1
#define REQUEST_PUT			2
#define REQUEST_HEADER		3
#define REQUEST_POST		4
#define REQUEST_UNKNOWN		1000

//	Fast variables
#define CONTENT_TYPE		0
#define CONTENT_LENGTH		1
#define IF_MODIFIED_SINCE	2
#define USER_AGENT			3
#define HOST				4
#define CONNECTION			5
#define PRAGMA				6
#define REFERER				7
#define COOKIE				8


#define HTTP_VAR(a, b)	((a)->Data[b].szData)

typedef struct _HTTP_SETTINGS
{
	DWORD	dwKeepAlive;
	DWORD	dwMaxFileContent;
	DWORD	dwMaxMemoryContent;

} HTTP_SETTINGS;


typedef struct _HTTP_CONTENTTYPE
{
	LPTSTR	tszFileExtension;
	LPSTR	szType;

} HTTP_CONTENTTYPE;


typedef struct _HTTP_VARIABLE
{
	LPSTR	szName;
	DWORD	dwName;

} HTTP_VARIABLE;


typedef struct _HTTP_HEADERDATA
{
	LPSTR	szData;
	DWORD	dwData;

} HTTP_HEADERDATA, * LPHTTP_HEADERDATA;


typedef struct _HTTP_CONTENT
{
	PCHAR	pData;
	DWORD	dwData;
	BOOL	bReceived;
	LONG	lLength;

	union
	{
			LONG	lReceived;
			LONG	lOffset;
	};

} HTTP_CONTENT, * LPHTTP_CONTENT;



typedef struct _HTTP_HEADER
{
	DWORD				dwRequest;
	LPSTR				szFileName;
	LPSTR				szArguments;
	BYTE				bProtocolVersion;

	HTTP_HEADERDATA		Data[10];	//	Pre-determinated variables

} HTTP_HEADER, * LPHTTP_HEADER;






#define REPLY_FILE		1
#define REPLY_BUFFER	2
#define REPLY_NONE		3

typedef struct _HTTP_REPLYDATA
{
	DWORD	dwType;
	LPSTR	szContentType;
	union
	{
		struct
		{
			IOFILE	Handle;
			DWORD	dwBufferSize;
		} File;
		struct
		{
			PCHAR pData;
			DWORD dwData;

		} Buffer;
	};
	struct _HTTP_REPLYDATA	*lpNext;

} HTTP_REPLYDATA, *LPHTTP_REPLYDATA;


typedef struct _HTTP_CONTENTINFO
{
	FILETIME	FileTime;
	BOOL		bFileTime;
	LPSTR		szType;
	UINT64		llSize;

} HTTP_CONTENTINFO, * LPHTTP_CONTENTINFO;



typedef struct _HTTP_REPLY
{
	DWORD				dwReplyCode;
	BUFFER				Header;
	LPHTTP_REPLYDATA	lpBody;
	BOOL				bContentType, bContentLength, bConnection;

} HTTP_REPLY, * LPHTTP_REPLY;



typedef struct _HTTP_VARIABLES
{
	LPTSTR	tszFileName;		//	Resolved filename to requested file
	LPSTR	szContentType;		//	Content type of filename ^^
	BYTE	bHeadersOnly;		//	Send only headers
	BYTE	bKeepAlive;			//	Session keep-alive

} HTTP_VARIABLES;




typedef struct _HTTP_USER
{
	CONNECTION_INFO		Connection;		//	Connection info
	COMMAND				DataChannel;	//	DataChannel

	HTTP_HEADER			Header;			//	Request header
	HTTP_CONTENT		Content;		//	Request content
	HTTP_REPLY			Reply;
	HTTP_VARIABLES		Variables;

} HTTP_USER, * PHTTP_USER, * LPHTTPUSER;


BOOL HTTP_Init(BOOL bFirstInitialization);