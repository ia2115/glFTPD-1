typedef struct _NEWCLIENT
{
	struct sockaddr_in		*lpLocalSockAddress;
	struct sockaddr_in		*lpRemoteSockAddress;
	CHAR				pBuffer[(sizeof(struct sockaddr_in) + 32) * 2];
	IOOVERLAPPED			Overlapped;
	SOCKET				Socket;
	LPIOSERVICE			lpService;
	LPSTR				szHostName;
	LPVOID				lpHostInfo;
	struct _NEWCLIENT	*lpNext;

} NEWCLIENT, * LPNEWCLIENT;
