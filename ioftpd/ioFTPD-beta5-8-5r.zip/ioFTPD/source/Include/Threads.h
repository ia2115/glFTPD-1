typedef struct _JOB
{
	LPVOID		lpProc;	//	Pointer for function to call
	LPVOID		lpContext;	//
	DWORD		dwFlags;

	struct _JOB	*lpNext;

} JOB, * LPJOB;


typedef struct _RESOURCE_DTOR
{
	VOID	(*lpProc)(VOID);
	struct _RESOURCE_DTOR	*lpNext;	

} RESOURCE_DTOR, *LPRESOURCE_DTOR; 


typedef struct _THREADDATA
{
	BOOL				bReuse;
	HANDLE				hEvent;
	struct _THREADDATA	*lpNext, *lpPrev;
	LPRESOURCE_DTOR		lpDestructor;

} THREADDATA, *LPTHREADDATA;





#define THREAD_STATUS_DELAYED	0x00000001



#define JOB_PRIORITY_HIGH	0
#define JOB_PRIORITY_NORMAL	1
#define JOB_PRIORITY_LOW	2
#define JOB_PRIORITY_DELAYED	3
#define JOB_FLAG_NOFIBER	(0x0001 << 16)


#define SSPI_ENCRYPT	0
#define SSPI_DECRYPT	1
#define CRC32			2



BOOL SetBlockingThreadFlag(VOID);
VOID SetNonBlockingThreadFlag(VOID);
BOOL InstallResourceDestructor(VOID (* lpProc)(VOID));
HANDLE GetThreadEvent(VOID);
BOOL QueueJob(LPVOID lpProc, LPVOID lpContext, DWORD dwPriority);
VOID QueueEncryption(LPIOOVERLAPPED lpOverlapped, DWORD dwCommand, LPVOID lpBuffer, DWORD dwBuffer);
BOOL Thread_Init(BOOL bFirstInitialization);
DWORD CalculateCrc32(PCHAR pOffset, DWORD dwBytes, PUINT32 pCrc32);
VOID Thread_DeInit(VOID);
