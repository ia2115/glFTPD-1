typedef struct _IOPORT
{
	USHORT			sLowPort;
	USHORT			sHighPort;
	struct _IOPORT	*lpNext;

} IOPORT, * LPIOPORT;

typedef struct _ACCEPT_SOCKET
{
	SOCKET			Socket;
	IOOVERLAPPED	Overlapped;

} ACCEPT_SOCKET, * LPACCEPT_SOCKET;


typedef struct _BANDWIDTH
{
	LPSOCKETOVERLAPPED	lpIOQueue[3][2];	//	IO Queues (synchronized, delayed, unsynchronized)
	DWORD				dwIOQueue[3];
	DWORD				dwClientBandwidthLimit;	//
	DWORD				dwGlobalBandwidthLimit;	//	Bandwidth limit
	DWORD				dwGlobalBandwidthLeft;	//	Bandwidth left
	BOOL				bGlobalBandwidthLimit;	//	Bandwidth limit is being enforced
	LONG volatile		lLock;				//	Lock

} BANDWIDTH, * LPBANDWIDTH;


typedef struct _IODEVICE
{
	LPTSTR				tszName;
	ULONG				lBindAddress;
	ULONG				lHostAddress;
	LPIOPORT			lpPort;
	BOOL				bActive;
	LONG volatile		lShareCount;
	DWORD				dwLastUpdate;
	BOOL				bRandomizePorts;
	LONG volatile		lLastPort;
	struct _IODEVICE	*lpNext;
	struct _IODEVICE	*lpPrev;

	//	Traffic shaping variables
	BANDWIDTH			Inbound;
	BANDWIDTH			Outbound;
	struct _IODEVICE	*lpNextSDevice;
	struct _IODEVICE	*lpPrevSDevice;

} IODEVICE, * LPIODEVICE;



typedef struct _IOSERVICE
{
	LPTSTR			tszName;
	BOOL			bActive;
	LPIODEVICE		lpDevice;
	LONG volatile	lAcceptSockets[2];
	DWORD			dwType;
	SOCKET			Socket;
	ULONG			lAddress;
	USHORT			sPort;

	LPTSTR		tszAllowedUsers;
	LPTSTR		tszRequireSecureAuth;
	LPTSTR		tszRequireSecureData;
	LPTSTR		tszMessageLocation;

	BOOL		bExternalIdentity;
	BOOL		bExplicitEncryption;
	LPVOID		hCredentials;
	LPIODEVICE	*lpDataDevices;
	DWORD		dwDataDevices;
	BOOL		bRandomDataDevices;

	DWORD		dwMaxClients;
	DWORD		dwClients;

	LONG volatile	lTransfers;
	LONG volatile	lConnections;
	LONG volatile	lLastDataDevice;

	LPVOID		lpAcceptProc;
	LPVOID		lpCloseProc;

	LOCKOBJECT			loLock;
	struct _IOSERVICE	*lpNext;

} IOSERVICE, * LPIOSERVICE;


#define	BIND_PORT		0001
#define	BIND_IP			0002
#define BIND_DATA		0004
#define BIND_REUSE		0010
#define BIND_MINUS_PORT	0020
#define BIND_FAKE		0100

#define C_TELNET	0
#define C_FTP		1
#define C_HTTP		2


LPIOSERVICE Service_FindByName(LPTSTR tszServiceName);
VOID Service_AcceptClient(LPVOID lpClient, DWORD dwBytesReceived, DWORD dwLastError);
BOOL Service_RequireSecureAuth(LPIOSERVICE lpService, LPUSERFILE lpUserFile);
BOOL Service_RequireSecureData(LPIOSERVICE lpService, LPUSERFILE lpUserFile);
BOOL Service_IsAllowedUser(LPIOSERVICE lpService, LPUSERFILE lpUserFile);
LPTSTR Service_MessageLocation(LPIOSERVICE lpService);

BOOL Service_Start(LPTSTR tszServiceName);
BOOL Service_Stop(LPTSTR tszServiceName);
BOOL Services_Start(VOID);
BOOL Services_Stop(VOID);
BOOL Services_Init(BOOL bFirstInitialization);
VOID Services_DeInit(VOID);

