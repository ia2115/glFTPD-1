typedef struct _Telnet_Vars
{
	//	Terminal variables
	UCHAR		Echo			: 1;
	UCHAR		Terminal_Type	: 1;
	UCHAR		Window_Size		: 1;
	UCHAR		Terminal_Speed	: 1;
	//	Other variables
	INT			LogOffset;

} TELNET_VARS;


typedef struct _TELNET_USER
{
	CONNECTION_INFO	Connection;			//	Connection info
	PUSERFILE		UserFile;			//	Userfile
	COMMAND			DataChannel;		//	DataChannel
	LPVOID			hMountFile;
	TELNET_VARS		TelnetVariables;	//	Telnet protocol specific variables

} TELNET_USER, * LPTELNETUSER;



typedef struct _TELNET_SETTINGS
{
	DWORD	dwSocketBuffer[2];
	DWORD	dwIdleTimeOut;
	DWORD	dwLoginTimeOut;
} TELNET_SETTINGS, * LPTELNET_SETTINGS;



#define ECHO	"\001"	// 001
#define LINE	"\""	// 034
#define WILL	"\373"	// 251
#define WONT	"\374"	// 252
#define DO		"\375"	// 253
#define DONT	"\376"	// 254
#define IAC		"\377"	// 255



BOOL Telnet_Init(BOOL bFirstInitialization);