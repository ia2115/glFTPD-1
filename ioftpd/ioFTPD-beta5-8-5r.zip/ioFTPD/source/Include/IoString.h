typedef struct _IO_STRING
{
	TCHAR		*pBuffer;
	TCHAR		*pString;
	TCHAR		**pMarks;
	
	DWORD	dwMarks;
	DWORD	dwShift;

} IO_STRING, * LPIO_STRING;


/*	Age old stuff	*/
struct _string {
	char			*data;
	unsigned short	len;
	unsigned short	size;
};

#define string_free(s)	free((s)->data);
extern void string_append(struct _string *dst, char *src, int s_len);
/*	------------	*/


#define ARG_NOERROR	0
#define ARG_IGNORE	(DWORD)-1


#define STR_BEGIN	0
#define STR_END		(DWORD)-1
#define STR_ALL		(DWORD)-1

#define GetStringItems(x)			((x)->dwMarks)
#define GetStringIndexLength(x, y)	((x)->pMarks[(y << 1) + 1] - (x)->pMarks[y << 1])


VOID FreeString(LPIO_STRING lpString);
LPTSTR GetStringRange(LPIO_STRING lpString, DWORD dwBeginIndex, DWORD dwEndIndex);
LPTSTR GetStringIndexStatic(LPIO_STRING lpString, DWORD dwIndex);
LPTSTR GetStringIndex(LPIO_STRING lpString, DWORD dwIndex);
VOID PullString(LPIO_STRING lpString, DWORD dwShift);
BOOL PushString(LPIO_STRING lpString, DWORD dwShift);
BOOL ConcatString(LPIO_STRING lpDestinationString, LPIO_STRING lpSourceString);
BOOL SplitString(LPTSTR tszStringIn, LPIO_STRING lpStringOut);