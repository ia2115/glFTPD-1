typedef struct _DATAROW
{
	LPSTR	szName;
	DWORD	dwOffset;
	DWORD	dwType;
	DWORD	dwMaxArgs;
	DWORD	dwMaxLength;	

} DATAROW, * LPDATAROW;


#define	DT_STRING	10
#define	DT_GROUPID	20
#define	DT_PASSWORD	30
#define	DT_INT32	32
#define	DT_INT64	64


VOID DataRow_Dump(LPBUFFER lpOutBuffer, LPVOID lpStorage, LPDATAROW lpDataRowArray, DWORD dwDataRowArray);
VOID DataRow_ParseBuffer(PCHAR pBuffer, DWORD dwBufferSize, LPVOID lpStorage, LPDATAROW lpDataRowArray, DWORD dwDataRowArray);