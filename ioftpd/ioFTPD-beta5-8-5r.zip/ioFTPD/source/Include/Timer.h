typedef struct _TIMER
{
	UINT64			ui64DueTime;
	LONG volatile		lStatus;
	LPVOID			lpTimerProc;
	LPVOID			lpTimerContext;
	struct _TIMER	*lpNext;

} TIMER, * LPTIMER;


#define	TIMER_ACTIVE	0
#define	TIMER_INACTIVE	1
#define	TIMER_CANCEL	2
#define	TIMER_QUEUED	3
#define	TIMER_WAIT	4

BOOL Timer_Init(BOOL bFirstInitialization);
VOID Timer_DeInit(VOID);
LPVOID StartIoTimer(LPVOID hTimer, LPVOID lpTimerProc, LPVOID lpTimerContext, DWORD dwTimeOut);
BOOL StopIoTimer(LPVOID hTimer, BOOL bInTimerProc);
BOOL DeleteIoTimer(LPTIMER lpTimer);
UINT WINAPI TimerThread(LPVOID lpVoid);