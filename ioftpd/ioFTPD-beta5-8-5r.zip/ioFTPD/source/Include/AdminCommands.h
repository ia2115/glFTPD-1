

typedef struct _ADMINCOMMAND
{
	LPTSTR	tszCommand;
	LPTSTR	(* lpProc)(LPVOID, DWORD, LPTSTR, LPIO_STRING);

} ADMINCOMMAND, * LPADMINCOMMAND;

LPVOID FindAdminCommand(LPTSTR tszCommand);
LPTSTR Admin_ChangeFileAttributes(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_ChangeFileMode(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_ChangeFileOwner(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_UsersOnline(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_Users(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_UserStats(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_UserInfo(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_Change(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_Config(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_Kick(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_AddUser(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_AddUserToGroup(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_DeleteUser(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_RenameUser(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_AddGroup(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_DeleteGroup(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_RenameGroup(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_ChangeUserGroups(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_AddIp(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_DeleteIp(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_SetOwnPassword(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_SetOwnTagline(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_Shutdown(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_Kill(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_Groups(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_GroupInfo(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);
LPTSTR Admin_Bans(LPVOID lpUser, DWORD dwDataType, LPTSTR tszMultilinePrefix, LPIO_STRING Args);