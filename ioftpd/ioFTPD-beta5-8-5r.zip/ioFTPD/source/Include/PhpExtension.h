
#define PHP_UINFO_DAYUP			offsetof(USERFILE, DayUp)
#define PHP_UINFO_DAYDN			offsetof(USERFILE, DayDn)
#define PHP_UINFO_WKUP			offsetof(USERFILE, WkUp)
#define PHP_UINFO_WKDN			offsetof(USERFILE, WkDn)
#define PHP_UINFO_MONTHUP		offsetof(USERFILE, MonthUp)
#define PHP_UINFO_MONTHDN		offsetof(USERFILE, MonthDn)
#define PHP_UINFO_ALLUP			offsetof(USERFILE, AllUp)
#define PHP_UINFO_ALLDN			offsetof(USERFILE, AllDn)
#define PHP_UINFO_MOUNTFILE		offsetof(USERFILE, MountFile)
#define PHP_UINFO_DESCRIPTION	offsetof(USERFILE, Tagline)
#define PHP_UINFO_HOMEDIR		offsetof(USERFILE, Home)
#define PHP_UINFO_FLAGS			offsetof(USERFILE, Flags)
#define PHP_UINFO_IPLIST		offsetof(USERFILE, Ip)
#define PHP_UINFO_ADMINGROUPS	offsetof(USERFILE, AdminGroups)
#define PHP_UINFO_GROUPS		offsetof(USERFILE, Groups)
#define PHP_UINFO_LIMITS		offsetof(USERFILE, Limits)
#define PHP_UINFO_PASSWORD		offsetof(USERFILE, Password)
#define PHP_UINFO_CREDITS		offsetof(USERFILE, Credits)

#define PHP_UINFO_START_SECTION	(DWORD)-1
#define PHP_UINFO_END_SECTION	(DWORD)-2
#define PHP_UINFO_NOBYTES		(DWORD)-3
#define PHP_UINFO_NOFILES		(DWORD)-4
#define PHP_UINFO_NOTIME		(DWORD)-5
#define PHP_UINFO_MERGE_STATS	(DWORD)-6

typedef struct _PHP_MASK
{
	DWORD	dwResource[64];
	DWORD	dwSize;
	LONG	lStartSection, lEndSection;
	BOOL	bFiles, bBytes, bTime, bMergeStats;

} PHP_MASK, * LPPHP_MASK;

#define N_PHP_USERFILE_MASK	"php_userfile_mask"
static INT	iUserFileMask;


#define PHP_CINFO_VIRTUALPATH		1
#define PHP_CINFO_VIRTUALDATAPATH	2
#define PHP_CINFO_REALPATH			3
#define PHP_CINFO_REALDATAPATH		4
#define PHP_CINFO_UID				5
#define PHP_CINFO_CID				6
#define PHP_CINFO_TRANSFERSPEED		7
#define PHP_CINFO_TRANSFERSTATUS	8
#define PHP_CINFO_TRANSFERPROGRESS	9
#define PHP_CINFO_LOGINTIME			10
#define PHP_CINFO_IDLETIME			11
#define PHP_CINFO_HOSTNAME			12
#define PHP_CINFO_IP				13
#define PHP_CINFO_IDENT				14

#define N_PHP_USERFILE		"ioftpd_userfile"
#define N_PHP_USERLIST		"ioftpd_userlist"
#define N_PHP_GROUPFILE		"ioftpd_groupfile"
#define N_PHP_GROUPLIST		"ioftpd_grouplist"
#define N_PHP_FILEINFO		"ioftpd_fileinfo"
#define N_PHP_MOUNTFILE		"ioftpd_mountfile"
#define N_PHP_CLIENTLIST	"ioftpd_clientlist"

#define IOFTPD_PHP_EXT_VERSION	1
static INT	iUserFile, iUserList;
static INT	iGroupFile, iGroupList;
static INT	iFileInfo, iMountFile;
static INT	iClientList;

#define PHP_FINFO_TYPE_SINGLE	1
#define PHP_FINFO_TYPE_FS_LIST	2


typedef struct _PHP_FILEINFO
{
	DWORD			dwType;				//	
	LPFILEINFO		lpFileInfo;			//	Fileinfo for current item
	VFSUPDATE		UpdateData;			//	Update data
	BOOL			bModified;			//	Set, if attributes have been modified
	DWORD			dwFileName;			//	Base length of filename (Purpose varies per type)
	LPTSTR			tszFileName;		//	Filename on disk

} PHP_FILEINFO, * LPPHP_FILEINFO;


typedef struct _PHP_FILEINFO_FS_LIST
{
	PHP_FILEINFO	FileInfo;
	LPVOID			hFind;

} PHP_FILEINFO_FS_LIST, * LPPHP_FILEINFO_FS_LIST;



typedef struct _PHP_USERFILE
{
	BOOL		bLocked;
	BUFFER		Buffer;
	union
	{
		LPUSERFILE	lpUserFile;
		LPGROUPFILE	lpGroupFile;
	};

} PHP_USERFILE, * LPPHP_USERFILE, PHP_GROUPFILE, * LPPHP_GROUPFILE;


typedef struct _PHP_CLIENTLIST
{
	DWORD		dwType[32];
	DWORD		dwCount;
	INT			iOffset;

} PHP_CLIENTLIST, * LPPHP_CLIENTLIST;



typedef struct _PHP_IDLIST
{
	LPINT	lpIdList;
	DWORD	dwIdList;
	DWORD	dwOffset;

} PHP_IDLIST, * LPPHP_IDLIST;



static VOID UserFile_Destructor(zend_rsrc_list_entry *lpResource TSRMLS_DC);
static VOID GroupFile_Destructor(zend_rsrc_list_entry *lpResource TSRMLS_DC);
static VOID IdList_Destructor(zend_rsrc_list_entry *lpResource TSRMLS_DC);
static VOID FileInfo_Destructor(zend_rsrc_list_entry *lpResource TSRMLS_DC);
static VOID MountFile_Destructor(zend_rsrc_list_entry *lpResource TSRMLS_DC);
static VOID ClientList_Destructor(zend_rsrc_list_entry *lpResource TSRMLS_DC);
static VOID UserFileMask_Destructor(zend_rsrc_list_entry *lpResource TSRMLS_DC);


PHP_FUNCTION(io_user_create);
PHP_FUNCTION(io_user_delete);
PHP_FUNCTION(io_user_rename);
PHP_FUNCTION(io_user_ingroup);
PHP_FUNCTION(io_user_open);
PHP_FUNCTION(io_user_print);
PHP_FUNCTION(io_user_save);
PHP_FUNCTION(io_user_lock);
PHP_FUNCTION(io_user_unlock);
PHP_FUNCTION(io_user_close);

PHP_FUNCTION(io_user_mask_init);
PHP_FUNCTION(io_user_query);
PHP_FUNCTION(io_user_mask_close);

PHP_FUNCTION(io_user_list_init);
PHP_FUNCTION(io_user_list_seek);
PHP_FUNCTION(io_user_list_fetch);
PHP_FUNCTION(io_user_list_close);
PHP_FUNCTION(io_user_name);
PHP_FUNCTION(io_user_id);


PHP_FUNCTION(io_group_create);
PHP_FUNCTION(io_group_delete);
PHP_FUNCTION(io_group_rename);
PHP_FUNCTION(io_group_open);
PHP_FUNCTION(io_group_print);
PHP_FUNCTION(io_group_save);
PHP_FUNCTION(io_group_lock);
PHP_FUNCTION(io_group_unlock);
PHP_FUNCTION(io_group_close);

PHP_FUNCTION(io_group_list_init);
PHP_FUNCTION(io_group_list_seek);
PHP_FUNCTION(io_group_list_fetch);
PHP_FUNCTION(io_group_list_close);
PHP_FUNCTION(io_group_name);
PHP_FUNCTION(io_group_id);

PHP_FUNCTION(io_client_kill);
PHP_FUNCTION(io_client_kick);
PHP_FUNCTION(io_client_list_init);
PHP_FUNCTION(io_client_list_fetch);
PHP_FUNCTION(io_client_list_close);

PHP_FUNCTION(io_fs_access);
PHP_FUNCTION(io_fs_flush);
PHP_FUNCTION(io_fs_open);
PHP_FUNCTION(io_fs_find_first);
PHP_FUNCTION(io_fs_find_next);
PHP_FUNCTION(io_fs_write);
PHP_FUNCTION(io_fs_modify);
PHP_FUNCTION(io_fs_query);
PHP_FUNCTION(io_fs_isdirectory);
PHP_FUNCTION(io_fs_modify_attribute);
PHP_FUNCTION(io_fs_query_attribute);
PHP_FUNCTION(io_fs_query_filename);
PHP_FUNCTION(io_fs_query_filesize);
PHP_FUNCTION(io_fs_close);
PHP_FUNCTION(io_fs_find_close);

PHP_FUNCTION(io_config_rehash);
PHP_FUNCTION(io_config_get_string);
PHP_FUNCTION(io_config_get_bool);
PHP_FUNCTION(io_config_get_int);
PHP_FUNCTION(io_config_get_perm);

PHP_FUNCTION(io_mtable_open);
PHP_FUNCTION(io_mtable_query);
PHP_FUNCTION(io_mtable_query_mounts);
PHP_FUNCTION(io_mtable_close);

PHP_FUNCTION(io_log);
PHP_FUNCTION(io_sha1);
PHP_FUNCTION(io_attachment);