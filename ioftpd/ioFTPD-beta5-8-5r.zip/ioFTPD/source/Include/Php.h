BOOL PHP_Init(BOOL bFirstInitialization);
VOID PHP_DeInit(VOID);
