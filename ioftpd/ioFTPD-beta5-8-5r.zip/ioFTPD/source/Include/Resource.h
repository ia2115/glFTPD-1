#ifndef _NOEXTERN
extern	HWND	MainWindow;
extern	LPVOID	(WINAPI *ShMem_Lock)(HANDLE, DWORD);
extern	BOOL	(WINAPI *ShMem_Unlock)(LPVOID);
#endif

#define IDC_TRAYICON		1000
#define IDM_EXIT			1001

BOOL Windows_Init(BOOL bFirstInitialization, HINSTANCE *hInstance);
VOID Windows_DeInit(VOID);