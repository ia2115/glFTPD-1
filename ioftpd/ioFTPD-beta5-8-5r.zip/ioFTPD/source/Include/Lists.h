#define DELETELIST(lpItem, lpList)				\
	if (lpItem->lpPrev)					\
	{							\
		lpItem->lpPrev->lpNext	= lpItem->lpNext;	\
	}							\
	else lpList[HEAD]	= lpItem->lpNext;		\
	if (lpItem->lpNext)					\
	{							\
		lpItem->lpNext->lpPrev	= lpItem->lpPrev;	\
	}							\
	else lpList[TAIL]	= lpItem->lpPrev;

#define	APPENDLIST(lpItem, lpList)				\
	if (! lpList[HEAD])					\
	{							\
		lpList[HEAD]	= lpItem;			\
		lpList[TAIL]	= NULL;				\
	}							\
	else lpList[TAIL]->lpNext	= lpItem;		\
	lpItem->lpPrev	= lpList[TAIL];				\
	lpList[TAIL]	= lpItem;				\
	lpItem->lpNext	= NULL;

#define	INSERTLIST(lpItem, lpList)				\
	if (! (lpItem->lpNext = lpList[HEAD]))			\
	{							\
		lpList[TAIL]	= lpItem;			\
	}							\
	else lpList[HEAD]->lpPrev	= lpItem;		\
	lpList[HEAD]	= lpItem;				\
	lpItem->lpPrev	= NULL;