#define	REMOVABLE			0001
#define	REMOVEALL			0004
#define	DENYALL				0010
#define	REMOVECURRENT			0020


#define	PRIMARY		0001
#define	SECONDARY	0002
#define	TERTIARY	0004
#define	QUATERNARY	0010
#define	QUINARY		0020
#define	SENARY		0040
#define	EXCLUSIVE	0100

#define CJOB_PRIMARY	00000001
#define CJOB_SECONDARY	00000002
#define CJOB_TERTIARY	00000004
#define CJOB_EXCLUSIVE	02000000
#define CJOB_INSTANT	01000000



typedef struct _CLIENTJOB
{
	DWORD				dwJobId, dwJobFlags;
	BOOL				(*lpJobProc)(LPVOID);
	VOID				(*lpCancelProc)(LPVOID);
	LPVOID				lpContext, hTimer;
	struct _CLIENTJOB		*lpNext;

} CLIENTJOB, * PCLIENTJOB, * LPCLIENTJOB;




VOID SetJobFilter(DWORD hClient, DWORD dwFlags);
BOOL AddClientJob(DWORD hClient, DWORD dwJobId, DWORD dwJobFlags, DWORD dwJobTimeOut, BOOL (* lpJobProc)(LPVOID), VOID (*lpCancelProc)(LPVOID), DWORD (*lpTimerProc)(LPVOID, LPTIMER), LPVOID lpContext);
VOID AddClientJobTimer(DWORD hClient, DWORD dwJobId, DWORD dwJobTimeOut, DWORD (*lpTimerProc)(LPVOID, LPTIMER));
BOOL EndClientJob(DWORD hClient, DWORD dwJobId);

