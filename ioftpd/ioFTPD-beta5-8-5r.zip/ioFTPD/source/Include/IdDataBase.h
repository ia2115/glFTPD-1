typedef struct _IDITEM
{
	INT32	Id;
	TCHAR	tszModuleName[_MAX_NAME + 1];
	TCHAR	tszName[_MAX_NAME + 1];

} IDITEM, * LPIDITEM;

typedef struct _FREED_IDITEM
{
	struct _FREED_IDITEM	*lpNext;

} FREED_IDITEM, * LPFREED_IDITEM; 


typedef struct _IDDATABASE
{
	LPTSTR		*lpNameTable[1024];
	LPIDITEM	*lpIdArray;
	DWORD		dwIdArraySize;
	DWORD		dwIdArrayItems;
	LPTSTR		tszFileName;

	LPFREED_IDITEM	lpFreedId;
	INT32		iNextFreeId;

	LOCKOBJECT	loDataBase;

} IDDATABASE, * LPIDDATABASE;

#define	DB_SUCCESS	0
#define	DB_DELETED	1
#define	DB_FATAL	2


BOOL IdDataBase_Init(LPTSTR tszTableLocation, LPIDDATABASE lpDataBase, LPVOID lpFindModuleProc, LPVOID lpReadIdDataProc);
BOOL IdDataBase_DeInit(LPIDDATABASE lpDataBase);
BOOL IdDataBase_Rename(LPTSTR tszName, LPTSTR tszModuleName, LPTSTR tszNewName, LPIDDATABASE lpDataBase);
INT32 IdDataBase_Add(LPTSTR tszName, LPTSTR tszModuleName, LPIDDATABASE lpDataBase);
BOOL IdDataBase_Remove(LPTSTR tszName, LPTSTR tszModuleName, LPIDDATABASE lpDataBase);
INT32 IdDataBase_SearchByName(LPTSTR tszName, LPIDDATABASE lpDataBase);
LPTSTR IdDataBase_SearchById(INT32 Id, LPIDDATABASE lpIdDataBase);
INT32 IdDataBase_GetNextId(LPINT lpOffset, LPIDDATABASE lpDataBase);
PINT32 IdDataBase_GetIdList(LPIDDATABASE lpDataBase, LPDWORD lpIdCount);