typedef struct _LOG_VECTOR
{
	DWORD				dwLogCode;
	FILETIME			FileTime;
	TCHAR				lpMessage[LOG_LENGTH];
	DWORD				dwMessageLength;
	struct _LOG_VECTOR	*lpNext;
	struct _LOG_VECTOR	*lpPrevious;

} LOG_VECTOR, * LPLOG_VECTOR;

#define LOG_SYSOP			0
#define LOG_ERROR			1
#define LOG_TRANSFER		2
#define LOG_GENERAL			3
#define LOG_DEBUG			4
#define LOG_SYSTEM			5

BOOL Putlog(DWORD dwLogCode, LPCSTR szFormatString, ...);
BOOL LogSystem_Init(VOID);
VOID LogSystem_DeInit(VOID);