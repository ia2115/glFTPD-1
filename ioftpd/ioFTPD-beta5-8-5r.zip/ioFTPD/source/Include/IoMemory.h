BOOL	Memory_Init(BOOL bFirstInitialization);
VOID	Memory_DeInit(VOID);

#define	SHARECOUNT(lpMem)	(((LPDWORD)lpMem)[-1])
#ifdef _LIMITED
//	Limited mode
LPVOID	MyHeapAllocate(DWORD dwSize);
BOOL	MyHeapFree(LPVOID lpMem);
LPVOID	MyHeapReAllocate(LPVOID lpMem, DWORD Size);

#define	_Allocate		MyHeapAllocate
#define _Free			MyHeapFree
#define _ReAllocate		MyHeapReAllocate
#else

//	Full Mode
LPVOID	FragmentAllocate(DWORD Size);
BOOL	FragmentFree(LPVOID Memory);
LPVOID	FragmentReAllocate(LPVOID lpMem, DWORD Size);

#define _Allocate		FragmentAllocate
#define _ReAllocate		FragmentReAllocate
#define _Free			FragmentFree
#endif


BOOL FreeShared(LPVOID lpMem);

#ifdef _DEBUG
//	Declarations
LPVOID DebugReAllocate(LPVOID lpMem, LPCSTR szDescription, DWORD dwSize);
BOOL DebugFree(LPVOID lpMem);
LPVOID DebugAllocate(LPCSTR szDescription, DWORD dwSize);
LPVOID _AllocateShared(LPVOID lpMem, LPSTR szDescription, DWORD dwSize);

#define Allocate(szDescription, dwSize)				DebugAllocate(szDescription, dwSize)
#define AllocateShared(lpMem, szDescription, dwSize)	_AllocateShared(lpMem, szDescription, dwSize)
#define ReAllocate(lpMem, szDescription, dwSize)	DebugReAllocate(lpMem, szDescription, dwSize)
#define Free(lpMem)									DebugFree(lpMem)
#else
LPVOID _AllocateShared(LPVOID lpMem, DWORD dwSize);

#define	Allocate(szDescription, dwSize)				_Allocate(dwSize)
#define AllocateShared(lpMem, szDescription, dwSize)	_AllocateShared(lpMem, dwSize)
#define	ReAllocate(lpMem, szDescription, dwSize)	_ReAllocate(lpMem, dwSize)
#define	Free(lpMem)									_Free(lpMem)

#endif