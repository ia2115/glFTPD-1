LPVOID QuickDelete(LPVOID *List, INT Items, LPVOID Item, INT (* Comp)(LPCVOID, LPCVOID), INT (* Check)(LPCVOID));
INT QuickInsert(LPVOID *List, INT Items, LPVOID Item, INT (* Comp)(LPCVOID, LPCVOID));
