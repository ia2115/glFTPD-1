#define LOCK_MAX_COUNT	10000

typedef struct _LOCKOBJECT
{
	HANDLE			hEvent[2];
	LONG volatile	lExclusive;

} LOCKOBJECT, *LPLOCKOBJECT;


VOID ReleaseExclusiveLock(LPLOCKOBJECT lpLockObject);
VOID AcquireExclusiveLock(LPLOCKOBJECT lpLockObject);
VOID ReleaseSharedLock(LPLOCKOBJECT lpLockObject);
VOID AcquireSharedLock(LPLOCKOBJECT lpLockObject);
VOID DeleteLockObject(LPLOCKOBJECT lpLockObject);
BOOL InitializeLockObject(LPLOCKOBJECT lpLockObject);


/*

typedef struct _LOCKOBJECT
{
	LONG volatile	lCounter;
	LONG volatile	lLock;
	BOOL			bExclusiveLock;
	HANDLE			hEvent;

} LOCKOBJECT, * LPLOCKOBJECT;


BOOL Lock_Init(VOID);
VOID Lock_DeInit(VOID);

VOID ReleaseExclusiveLock(LPLOCKOBJECT lpLock);
VOID AcquireExclusiveLock(LPLOCKOBJECT lpLock);
VOID ReleaseSharedLock(LPLOCKOBJECT lpLock);
VOID AcquireSharedLock(LPLOCKOBJECT lpLock);
VOID DeleteLockObject(LPLOCKOBJECT lpLock);
BOOL InitializeLockObject(LPLOCKOBJECT lpLock); */
