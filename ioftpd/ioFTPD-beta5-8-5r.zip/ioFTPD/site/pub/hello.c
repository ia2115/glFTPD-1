#include <stdio.h>
#include <stdlib.h>

main() { printf("%s\n", "hello, world"); exit(0); }
