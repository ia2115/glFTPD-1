#include <StdIo.h>
#include <IoFTPD.h>
#include <Windows.h>
#if 0
#include <ServerLimits.h>
#include <VFS.h>
#include <Time.h>
#include <Userfile.h>
#include <WinMessages.h>
#include <DataCopy.h>
#endif

HANDLE	(WINAPI *ShMem_Allocate)(LPVOID, ULONG, DWORD);
LPVOID	(WINAPI *ShMem_Lock)(HANDLE, DWORD);
BOOL	(WINAPI *ShMem_Unlock)(LPVOID);
BOOL	(WINAPI *ShMem_Free)(HANDLE, DWORD);







INT main(INT ArgC, LPSTR ArgV[])
{
	LPDC_MESSAGE	lpMessage;
	LPDC_NAMEID		pNameId;
	PUSERFILE		pUserFile;
	LPDC_VFS			pFileInformation;
	HMODULE			hShell32;
	HANDLE			hSharedMemory, hEvent;
	LPVOID			lpContext, hMemory;
	LPSTR			FileName, tFileName;
	DWORD			dwProcessId, l_FileName, dwMaxContextSize, dwAllocationSize;
	DWORD			dwReturn, dwFileAttributes;
	CHAR			UserName[_MAX_NAME + 1], GroupName[_MAX_NAME + 1];
	HWND			hIoFTPD;
	INT				UserId, GroupId;

	if (ArgC < 2)
	{
		printf("ERROR: Not enough arguments!\n");
		exit(2);
	}

	//	Get file type
	dwFileAttributes	= GetFileAttributes(ArgV[1]);

	if (dwFileAttributes == INVALID_FILE_ATTRIBUTES)
	{
		printf("ERROR: \"%s\" does not exist!\n", ArgV[1]);
		exit(2);
	}

	hEvent				= INVALID_HANDLE_VALUE;
	lpMessage			= NULL;
	pFileInformation	= NULL;
	hSharedMemory		= NULL;
	FileName			= ArgV[1];
	l_FileName			= strlen(FileName);
	dwMaxContextSize	= 1024;
	//	Load shell library
	hShell32	= LoadLibrary("shell32.dll");
	//	Find ioFTPD message window
	hIoFTPD	= FindWindow("ioFTPD::MessageWindow", NULL);
	//	Get process id
	dwProcessId	= GetCurrentProcessId();
	//	Make sure window exists
	if (! hIoFTPD) goto DONE;
	//	Determinate amount of memory to allocate for vfs reader
	dwAllocationSize	= dwMaxContextSize + (l_FileName + 1) + sizeof(DC_VFS) + sizeof(DC_MESSAGE);
	//	Compare against amount of memory needed for userfile reader
	if (dwAllocationSize < sizeof(USERFILE) + sizeof(DC_MESSAGE))
	{
		dwAllocationSize	= sizeof(USERFILE) + sizeof(DC_MESSAGE);
	}
	//	Compare against amount of memory needed for user id resolving
	if (dwAllocationSize < sizeof(DC_NAMEID) + sizeof(DC_MESSAGE))
	{
		dwAllocationSize	= sizeof(DC_NAMEID) + sizeof(DC_MESSAGE);
	}
	//	Create event
	hEvent	= CreateEvent(NULL, FALSE, FALSE, NULL);
	//	Validate event
	if (hEvent == INVALID_HANDLE_VALUE) goto DONE;

	//	Allocate memory
	if (hShell32)
	{
		//	Get shared memory functions
		ShMem_Allocate	= (HANDLE (WINAPI *)(LPVOID, ULONG, DWORD))GetProcAddress(hShell32, "SHAllocShared");
		ShMem_Free		= (BOOL (WINAPI *)(HANDLE, DWORD))GetProcAddress(hShell32, "SHFreeShared");
		ShMem_Unlock	= (BOOL (WINAPI *)(LPVOID))GetProcAddress(hShell32, "SHUnlockShared");
		ShMem_Lock		= (LPVOID (WINAPI *)(HANDLE, DWORD))GetProcAddress(hShell32, "SHLockShared");

		//	Allocate memory
		if (ShMem_Allocate && ShMem_Free &&
			ShMem_Lock && ShMem_Unlock)
		{
			//	Shared memory exists - allocate memory
			hSharedMemory	= ShMem_Allocate(NULL, dwAllocationSize, dwProcessId);
			//	Check allocation
			if (hSharedMemory == INVALID_HANDLE_VALUE) goto DONE;
			//	Lock allocation
			lpMessage	= (LPDC_MESSAGE)ShMem_Lock(hSharedMemory, dwProcessId);
		}
	}
	//	Allocation failed
	if (! lpMessage) goto DONE;
	//	Copy Message id
	lpMessage->hEvent		= hEvent;
	lpMessage->dwIdentifier	= DC_FILEINFO_READ;
	lpMessage->lpMemoryBase	= lpMessage;
	lpMessage->lpContext	= (LPVOID)((ULONG)lpMessage + sizeof(DC_MESSAGE));
	//	Get offsets for local items
	pFileInformation	= (LPDC_VFS)lpMessage->lpContext;
	lpContext			= (LPVOID)((ULONG)lpMessage->lpContext + sizeof(DC_VFS));
	tFileName			= (LPSTR)((ULONG)lpMessage->lpContext + dwMaxContextSize + sizeof(DC_VFS));
	pNameId				= (PDC_NAMEID)lpMessage->lpContext;
	pUserFile			= (PUSERFILE)lpMessage->lpContext;
	//	Send initialization message
	hMemory	= (LPVOID)SendMessage(hIoFTPD,
		WM_SHMEM_ALLOC, (WPARAM)dwProcessId, (LPARAM)hSharedMemory);
	//	Verify handle
	if (! hMemory) goto DONE;

	//	Set maximum size for context
	pFileInformation->dwContextSize	= dwMaxContextSize;
	//	Copy filename (including padding '\0' char)
	CopyMemory(tFileName, FileName, l_FileName + 1);
	//	Determinate type
	pFileInformation->bDirectory	=
		(dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ? TRUE : FALSE);
	//	Send message to ioFTPD
	dwReturn	= SendMessage(hIoFTPD, WM_SHMEM, NULL, (LPARAM)hMemory);

	if (! dwReturn)
	{
		//	Wait until processed
		WaitForSingleObject(hEvent, INFINITE);
		//	Store user & group id
		UserId		= pFileInformation->FileAttributes.Uid;
		GroupId		= pFileInformation->FileAttributes.Gid;
		tFileName	= (LPSTR)((ULONG)pFileInformation + pFileInformation->dwContextSize + sizeof(DC_VFS));

		//	Change owner user & group
		lpMessage->dwIdentifier	= DC_VFS_WRITE;
		pFileInformation->FileAttributes.Uid	= 101;
		pFileInformation->FileAttributes.Gid	= 100;

		//	Copy filename to new location
		CopyMemory(tFileName, FileName, l_FileName + 1);

		if (! SendMessage(hIoFTPD, WM_SHMEM, NULL, (LPARAM)hMemory))
		{
			//	Wait until processed
			WaitForSingleObject(hEvent, INFINITE);
			//	Get result
			if (! lpMessage->dwReturn) printf("Notice: Updated file owner\n");
		}

		//	Resolve user id
		lpMessage->dwIdentifier	= DC_UID_TO_USER;

		pNameId->Id			= UserId;
		pNameId->szName[0]	= '\0';

		strcpy(UserName, "NoOne");

		if (! SendMessage(hIoFTPD, WM_SHMEM, NULL, (LPARAM)hMemory))
		{
			//	Wait until processed
			WaitForSingleObject(hEvent, INFINITE);
			//	Copy result
			if (! lpMessage->dwReturn) strcpy(UserName, pNameId->szName);
		}

		//	Resolve group id
		lpMessage->dwIdentifier	= DC_GID_TO_GROUP;

		pNameId->Id			= GroupId;
		pNameId->szName[0]	= '\0';

		strcpy(GroupName, "NoGroup");

		if (! SendMessage(hIoFTPD, WM_SHMEM, NULL, (LPARAM)hMemory))
		{
			//	Wait until processed
			WaitForSingleObject(hEvent, INFINITE);
			//	Copy result
			if (! lpMessage->dwReturn) strcpy(GroupName, pNameId->szName);
		}

		//	Open userfile (by user id - not possible by name)
		lpMessage->dwIdentifier	= DC_USERFILE_OPEN;
		pUserFile->Uid	= UserId;

		if (! SendMessage(hIoFTPD, WM_SHMEM, NULL, (LPARAM)hMemory))
		{
			//	Wait until done
			WaitForSingleObject(hEvent, INFINITE);
	
			//	Lock userfile (exclusive, required only when writing)
			lpMessage->dwIdentifier	= DC_USERFILE_LOCK;

			if (! lpMessage->dwReturn &&
				! SendMessage(hIoFTPD, WM_SHMEM, NULL, (LPARAM)hMemory))
			{
				//	Wait until done
				WaitForSingleObject(hEvent, INFINITE);

				if (! lpMessage->dwReturn)
				{
					//	Add some credits on credit section 0
					pUserFile->Credits[0]	+= 1000;
					//	Unlock userfile (if this is not done, io will go crazy..)
					lpMessage->dwIdentifier	= DC_USERFILE_UNLOCK;
					if (! SendMessage(hIoFTPD, WM_SHMEM, NULL, (LPARAM)hMemory))
					{
						//	Wait until done
						WaitForSingleObject(hEvent, INFINITE);
						//	Print some crap on success:)
						if (! lpMessage->dwReturn)
						{
							printf("%s - %s/%s rewarded with 1000creds\n", FileName, UserName, GroupName);
						}
					}
				}
			}
			//	Close userfile
			lpMessage->dwIdentifier	= DC_USERFILE_CLOSE;;
			if (! SendMessage(hIoFTPD, WM_SHMEM, NULL, (LPARAM)hMemory))
			{
				//	Wait until done
				WaitForSingleObject(hEvent, INFINITE);
			}
		}
	}
DONE:
	//	Free shared memory
	if (hSharedMemory)
	{
		if (hMemory) SendMessage(hIoFTPD, WM_SHMEM_FREE, NULL, (LPARAM)hMemory);
		if (lpMessage) ShMem_Unlock(lpMessage);
		ShMem_Free(hSharedMemory, dwProcessId);
	}
	//	Close event
	if (hEvent != INVALID_HANDLE_VALUE) CloseHandle(hEvent);
	//	Unload library
	if (hShell32) FreeLibrary(hShell32);
	exit(0);

	return FALSE;
}
