The /include directory is no longer being distributed in the end-user
distributions.  Please download the associated ioftpd-<ver>-src.zip file
from the forum and use the include directory found there.
