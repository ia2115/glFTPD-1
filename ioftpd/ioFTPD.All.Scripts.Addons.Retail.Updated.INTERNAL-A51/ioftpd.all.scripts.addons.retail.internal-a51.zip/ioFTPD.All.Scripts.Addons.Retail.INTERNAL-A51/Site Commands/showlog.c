/*
   io showlog for ioFTPD by mr_F [Jan 25th, 2004]
   1.2:
   	added : list releases user downloaded
   1.1:
   	added "command returned no results" message
   1.0:
   	initial release
*/
#include <stdio.h>
#include <string.h>
#include <malloc.h>

//APPLICATION DEFAULTS
#define DEFAULTSHOW 	10			//default number of results to show if no parameter is entered
#define DEFAULTRLSLIST	10			//default number of releases to list on -r command
#define MAXOUTPUTLEN	115			//maximum characters to display client status window
#define BUFFER			1500			//maximum possible line length in xferlog before parsing off text
#define MAXOUTPUT		1000			//maximum possible results to output (needs this much stack room)
#define MAX_PATH_SIZE	2000			//maximum directory path length
#define XFERLOGPATH	"..\\logs\\xferlog"	//path to xferlog from where ioFTPD.exe is located
#define USER_FILE_SEPERATOR "    "		//seperator for [##] USERNAME____FILENAME, replaces _____


// TOGGLES
#define NOT_AVAILABLE____SHOWAGE	1				//show age of download 
							// 0 = off
							// 1 = on
#define SHOWFULLPATH 1 		     //mode of results output:
							//	0 = filename only
							//	1 = release directory and filename
							//	2 = full path and filename
struct info_t {
	   char *file,
	   *user,
	   *date,
	   *io;
};

int checkrlslist(char *file, char *rlslist[], int *l, int *starton, int maxtrue);
int ismulti(char *path, char *multicdstring);
int contains(char *one, char *two, int *l);

//set these in ALL capitals
char multicdstr[] = {"CD1,CD2,CD3,CD4,CD5,CD6,CD,7,CD8,CD,CD10,DISC1,DISC2,DISC3,DISC4,DISC5,SAMPLE,SUBS,DVD,EXTRA"};

int stoi(char numstring[],int stringlength);

int
main(int argc, char *argv[])
{
	FILE *xfer;
	char *user, readline[BUFFER], *stack[MAXOUTPUT]={NULL}, direction='o';
	unsigned int x=0,i,l,v=0;
	int byrls=0;
	unsigned long maxresults=DEFAULTSHOW;
	
	if (argc==1)
	{
		printf("+----[SiTE SHOWLOG]--------------------------------------+\n");
		printf("| List last x files downloaded/uploaded by <user>        |\n");
		printf("| Usage: site showlog <user> [max results] [direction]   |\n");		
		printf("|  user can be 'all', direction is either nothing or 'up'|\n");
		printf("|                                                        |\n");
		printf("| List last x releases downloaded by <user>              |\n");		
		printf("| Usage: site showlog <user> [max results] -r	          |\n");
		printf("+--------------------------------------------------------+\n");
		return 0;
	} else
		user=argv[1];

	if (argc==3 && !strcmp(argv[2],"up"))
		direction='i';
	else if (argc==4 && !strcmp(argv[3],"up"))
		direction='i';
	else if ((argc==4 && !strcmp(argv[3],"up")) || (argc==5 && !strcmp(argv[4],"up")))
	{
		byrls=1;
		direction='i';
	}

	if (argc==3 && !strcmp(argv[2],"-r"))
		byrls=1;
	else if (argc==4 && !(v=strcmp(argv[2],"-r"))) //"up"
		byrls=1;
	else if (argc==4 && !strcmp(argv[3],"-r"))
		byrls=1;
	else if (argc==5)
		byrls=1;


	if (argc==3 && strcmp(argv[2],"up") && !byrls)			//username ## up
		maxresults=stoi(argv[2],strlen(argv[2]));	
	else if (argc==4 && byrls && v)					//username ## -r
		maxresults=stoi(argv[2],strlen(argv[2]))+1;	//+1 for the way the stack works
	else if (argc==4 && !strcmp(argv[3],"up") && !byrls)
		maxresults=stoi(argv[2],strlen(argv[2]));
	else if (argc==5) //username ## -r up ONLY way
		maxresults=stoi(argv[2],strlen(argv[2]));
	else if (byrls)							//username -r
		maxresults=DEFAULTRLSLIST+1;
	else								   //username
	   	maxresults=DEFAULTSHOW;

	if (maxresults>MAXOUTPUT)
		   maxresults=MAXOUTPUT;  //avoid buffer overflow

	if (!(xfer=fopen(XFERLOGPATH,"r")))
	{
		printf("No download logs available.\n");
		return 0;
	}

	l = strlen(user);
	l += strlen(USER_FILE_SEPERATOR);
	while (fgets(readline,BUFFER,xfer)!=NULL)
	{
		char *ptr_usr, *ptr_file,*ptr_date,*ptr_io,*ptr;
#if (SHOWFULLPATH==1)
		char *ptrlock;
#endif
		int A=0;

		ptr_date=strchr(readline,0x20);
		ptr_file=strchr(ptr_date,'/');
		ptr_usr=strrchr(ptr_file,'_');

		ptr_file[ptr_usr-ptr_file-3]=0;

		ptr_io=ptr_usr+2;
		ptr_usr+=6;
		ptr=strchr(ptr_usr,0x20);
		ptr[0]=0;

		if (*ptr_io==direction && (!strcmp(user,ptr_usr) || !strcmp(user,"all")))
		{
#if (SHOWFULLPATH==1)
     		char *pptr;
			unsigned int len;
#endif			
			if (x >= maxresults)
			{
				free(stack[x-maxresults]);
				stack[x-maxresults]=NULL;
			}
			else if (x <= maxresults && stack[MAXOUTPUT-maxresults+x]!=NULL)
			{
				free(stack[MAXOUTPUT-maxresults+x]);
				stack[MAXOUTPUT-maxresults+x]=NULL;
			}

			if (byrls==0)
			{
				stack[x] = malloc(sizeof(char) * (strlen(ptr_usr) + strlen(ptr_file) +7));
				strcpy(stack[x],ptr_usr);
				strcat(stack[x],USER_FILE_SEPERATOR);
			} else if (!strcmp(user,"all"))
			{
				   printf("Cannot list 'all' in list release mode\n");
				   return 0;
			} else if (direction=='i')
			{
				   printf("Cannot list uploads in release mode /YET/\n");
				   return 0;
			}	   
			
#if (SHOWFULLPATH==2)
			strcat(stack[x],ptr_file);
#elif (SHOWFULLPATH==1)
			pptr=strrchr(ptr_file,'/');	//pptr = /filename
			pptr[0]='?';			   	//pptr = ?filename
			ptrlock=pptr;				//ptrlock = _
			pptr=strrchr(ptr_file,'/');	//pptr = /DIReCTORY_filename
			if (ismulti(pptr+1,multicdstr))
			{
				   char *ptrlock2;
				   pptr[0]='?';
				   ptrlock2=pptr;
				   pptr=strrchr(ptr_file,'/');
				   ptrlock2[0]='/';
			}
			pptr++;					//pptr = directory_filename
			ptrlock[0]='/';			//pptr = directory/filename
			

			if (byrls==1)
			{
				char *xptr;
				int a,starton=0;
				
				while ((xptr = strrchr(pptr,'/'))) //OH CUTS (off the Filename and CD# :D)
					xptr[0]=0;

				if (x >= maxresults)
					starton=(x+1)-maxresults;


				(A+=a=checkrlslist(pptr,stack,&l,&starton,(x>=maxresults)));
			   	if ((unsigned)A < maxresults)
				{
					   //add to stack
					   if (a==0)
					   {
						    // free(stack[x]);
							 continue;
					   }
					   else
					   {

						   stack[x] = malloc(sizeof(char) * (strlen(ptr_usr) + strlen(ptr_file) +7));
						   strcpy(stack[x],ptr_usr);
						   strcat(stack[x],USER_FILE_SEPERATOR);
						   len = strlen(stack[x]);
						   strncat(stack[x],pptr,MAXOUTPUTLEN-len);
							x++;
							if (x >= MAXOUTPUT)
								starton++;
							if (x ==MAXOUTPUT)
							{
								x=0;
								starton=0;
							}
					   }
				} else	//memory is full
					   break;
   			   continue;
			}		

			len = strlen(stack[x]);
			strncat(stack[x],pptr,MAXOUTPUTLEN-len);
			if ((strlen(stack[x])) >= MAXOUTPUTLEN)
				strcat(stack[x],"...");
#else
			ptr_file=strrchr(ptr_file,'/');
			ptr_file++;
			strcat(stack[x],ptr_file);
#endif			

			x++;
			if (x == MAXOUTPUT)
				x=0;

		}
	}

	for (i=1,--x; i<=maxresults && stack[x]!=NULL && x != -1; i++,x--)
	{
		printf("[%2d] %s\n",i,stack[x]);

		if (x==0)
			x=MAXOUTPUT;
	}
	
	if (i==1)
		   printf("Your command came up with no matches.\n");
	
	return 0;
}

int
stoi(char numstring[],int stringlength)
{
	int a,b=0,c,output=0;

	for (a=stringlength-1; a >=0; a--)
	{
		int multiplier=1;
		for (c=0; c < b; c++)
			multiplier *= 10;

		output += (numstring[a]-48) * multiplier;
		b++;
	}

	return(output);
}

int
ismulti(char *path, char *multicdstring)
{
	   char *string;
	   char *ptr=NULL;
	   long i;
	   i = strlen(path);
	   string = malloc(sizeof(char) * (i + 1));
	   string[i]=0;
	   for (;i>=0;i--)
	   {
		if (path[i]>96 && path[i]<123)
			   string[i]=path[i]-32;
		else if (path[i]=='?')
			   string[i]=0;
		else
			   string[i]=path[i];
	   }
	   
	   ptr=strstr(multicdstring,string);
	   free(string);
	return (ptr!=NULL);
}

int
checkrlslist(char *file, char *rlslist[], int *l, int *starton, int maxtrue)
{
	int i;

	for(i=*starton; rlslist[i]!=NULL; i++)
	{
		   if (!contains(rlslist[i],file, l))
		   {
				if (maxtrue)
				{
					int z;
					char *intermed;

					//move the file from where it was to the top item in the stack
					intermed=rlslist[i];
					for(z=i; rlslist[z] != NULL ; z++)
							rlslist[z]=rlslist[z+1];
					rlslist[--z]=intermed;
				}

				return 0; //release is found, return code 0
		   }
		   
	}
	return 1;
}

int
contains(char *one, char *two, int *l)
{
	int pos;
	for (pos=0;one[*l+pos]==two[pos] && one[*l+pos]!=0 && two[pos]!=0;pos++);

	return (!(two[pos]==0));
}
