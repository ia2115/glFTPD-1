<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>R2i Userfile Converter</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php

$homedir = "D:\\Documents\\htdocs\\mouton.abuserz\\r2i";
$winrar = "\"C:\\Program Files\\WinRAR\\rar.exe\"";

if (!isset($_POST['Submit'])) {
	?>
	<form name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>">
	  <p> .user file:<br>
		<textarea name="userfile" cols="70" rows="10" id="userfile"></textarea>
	  </p>
	  <p> .allow file:<br>
		<textarea name="allowfile" cols="70" rows="10" id="allowfile"></textarea>
	  </p>
	  <p> 
	        <input type="checkbox" name="unique_pwd" value="true" checked> Generate unique passwords for each user. The passwords will be UsernameUID. Ex: "Mouton100" for user Mouton with UID=100. See UserIdTable for the list of UIDs.<br>Otherwise, it will use 'ioFTPD' for all accounts.
          </p> 
	  <p>
		<input type="submit" name="Submit" value="Convert">
	  </p>
	</form>
	<?php
} else {
	// Convert
	echo "Converting...<br>";
	$users = split("\r\n",$_POST['userfile']);
	$allows = split("\r\n",$_POST['allowfile']);
	echo "Number of users found: ".sizeof($users)."<br>";
	$i = 1;
	foreach ($users as $userline) {
		if ($userline=="")
			continue;
		#echo "$userline<br>";
		$userData = split(":",$userline);

		// Format: username:userlevel(0=root,1=super,2=normal):[encrypted_pass]:group:enabled:DL_speed_limit(kb):UL_speed_limit(kb):ratio:max_logins:disable_ip_check(0/1):downloaded_kb:uploaded_kb:tagline:[language]:pwd:credits(mb):allow_selfkick(0/1):authentification_type(0-7):file_system(VFS/personal):expire_date:allow_fxp_upload(0/1):allow_fxp_download(0/1):
		$username[$i] = $userData[0];
		$userlevel[$i] = $userData[1];
		$group[$i] = $userData[3];
		$enabled[$i] = $userData[4];
		$maxspeedDn[$i] = $userData[5];
		$maxspeedUp[$i] = $userData[6];
		$ratio[$i] = $userData[7];
		$max_logins[$i] = $userData[8];
		$no_ip_check[$i] = $userData[9];
		$downloaded_kb[$i] = $userData[10];
		$uploaded_kb[$i] = $userData[11];
		$tagline[$i] = $userData[12];
		$credits[$i] = number_format(round($userData[15]*1024),0,"","");

		if (sizeof($userData)>20) {
			$allow_fxp_up[$i] = $userData[20];
			$allow_fxp_dn[$i] = $userData[21];
		}

		$i++;
	}

	?>
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td>UserID</td>
		<td>Username</td>
		<td>User-level</td>
		<td>Group</td>
		<td>Enabled</td>
		<td>Max Dn Speed (kBps)</td>
		<td>Max Up Speed (kBps)</td>
		<td>Ratio</td>
		<td>Max Logins</td>
		<td>Downloaded (kB)</td>
		<td>Uploaded (kB)</td>
		<td>Tagline</td>
		<td>Credits (kB)</td>
	  </tr>

	<?php

	mkdir("$homedir\\output\\etc");
	mkdir("$homedir\\output\\users");
	mkdir("$homedir\\output\\groups");

	$j = 1;
	while ($j<$i) {
		echo "<tr>";
		echo "<td>".($j+99)."</td>";
		echo "<td>$username[$j]</td>";
		echo "<td>$userlevel[$j]</td>";
		echo "<td>$group[$j]</td>";
		echo "<td>$enabled[$j]</td>";
		echo "<td>$maxspeedDn[$j]</td>";
		echo "<td>$maxspeedUp[$j]</td>";
		echo "<td>$ratio[$j]</td>";
		echo "<td>$max_logins[$j]</td>";
		echo "<td>$downloaded_kb[$j]</td>";
		echo "<td>$uploaded_kb[$j]</td>";
		echo "<td>$tagline[$j]</td>";
		echo "<td>$credits[$j]<br>";
		echo "</tr>";

		switch ($userlevel[$j]) {
			case 0:		$flags = "MTH"; break;
			case 1:		$flags = "1"; break;
			case 2:		$flags = "3"; break;
			default:	$flags = "3"; break;
		}
		if ($max_logins[$j]=="-1")
			$flags .= "L";
		if ($allow_fxp_up[$j]==0)
			$flags .= "f";
		if ($allow_fxp_dn[$j]==0)
			$flags .= "F";

		$groups = split(",",$group[$j]);
		$gid = 99; $gids = "";
		foreach($groups as $groupN) {
			@$fp = fopen("$homedir\\output\\etc\\GroupIdTable","r");
			$found = 0;
			if ($fp) {
				while(!feof($fp)) {
					$line = fgets($fp);
					if ($line=="" || $line=="\n") continue;
					$line = str_replace("\n","",$line);
					$line = str_replace("\r","",$line);
					$array = split(":",$line);
					$gid = $array[1];
					if ($array[0]==$groupN) {
						$found=1;
						break;
					}
				}
				fclose($fp);
			}
			if (!$found) {
				$fp = fopen("$homedir\\output\\etc\\GroupIdTable","a");
				$gid = $gid + 1;
				fputs($fp,"$groupN:$gid:STANDARD\n");
				fclose($fp);

				$groupfile = "DESCRIPTION New group\n";
				$groupfile .= "USERS 1\n";
				$groupfile .= "SLOTS 0 0\n";
				$groupfile .= "VFSFILE \n";
				$fp = fopen("$homedir\\output\\groups\\$gid","w");
				fwrite($fp,$groupfile);
				fclose($fp);
			} else {
				// Increment usercount in groupfile
				@$fp = fopen("$homedir\\output\\groups\\$gid","r");
				if ($fp) {
					while(!feof($fp)) {
						$line = fgets($fp);
						if ($line=="" || $line=="\n") continue;
						$line = str_replace("\n","",$line);
						$line = str_replace("\r","",$line);
						if (strstr($line,"USERS ")) {
							$array = split(" ",$line);
							$users = $array[1];
							break;
						}
					}
					fclose($fp);
				}
				$users++;
				unlink("$homedir\\output\\groups\\$gid");

				$groupfile = "DESCRIPTION New group\n";
				$groupfile .= "USERS $users\n";
				$groupfile .= "SLOTS 0 0\n";
				$groupfile .= "VFSFILE \n";
				$fp = fopen("$homedir\\output\\groups\\$gid","w");
				fwrite($fp,$groupfile);
				fclose($fp);
			}
			$gids .= "$gid ";
		}

		// Allowed IP
		reset($allows);
		$ips = "";
		if ($no_ip_check[$j] == 1) {
			$ips .= "*@*";
		} else {
			foreach($allows as $ip) {
				if (strstr($ip,"$username[$j]@")) {
					$allow = substr($ip,strlen($username[$j])+1);
					if (!strstr($allow,"@"))
						$allow = "*@$allow";
					$ips .= "$allow ";
				}
			}
		}
		if ($ips == "")
			$ips = "*@*";
			
		if (isset($_POST['unique_pwd']) && isset($_POST['unique_pwd'])=="true") {
			$pwd = sha1("$username[$j]".($j+99));
		} else {
			$pwd = "6045b1757913f659b210fceb4f2746d74d4d6b32";
		}

		// Build userfile
		$userfile = "admingroups\n";
		$userfile .= "alldn 0 $downloaded_kb[$j] 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n";
		$userfile .= "allup 0 $uploaded_kb[$j] 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n";
		$userfile .= "credits $credits[$j] 0 0 0 0 0 0 0 0 0\n";
		$userfile .= "daydn 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n";
		$userfile .= "dayup 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n";
		$userfile .= "flags $flags\n";
		$userfile .= "groups $gids\n";
		$userfile .= "home /\n";
		$userfile .= "ips $ips\n";
		$userfile .= "limits $maxspeedDn[$j] $maxspeedUp[$j] 0 $max_logins[$j] 0\n";
		$userfile .= "monthdn 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n";
		$userfile .= "monthup 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n";
		$userfile .= "password $pwd\n";
		$userfile .= "ratio $ratio[$j] 0 0 0 0 0 0 0 0 0\n";
		$userfile .= "tagline $tagline[$j]\n";
		$userfile .= "wkdn 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n";
		$userfile .= "wkup 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n";

		$fp = fopen("$homedir\\output\\users\\".($j+99),"w");
		fwrite($fp,$userfile);
		fclose($fp);

		$fp = fopen("$homedir\\output\\etc\\UserIdTable","a");
		fwrite($fp,"$username[$j]:".($j+99).":STANDARD\n");
		fclose($fp);

		$j++;
	}
	?></table><?php

	// Add NoGroup
	$fp = fopen("$homedir\\output\\etc\\GroupIdTable","a");
	fputs($fp,"NoGroup:1:STANDARD\n");
	fclose($fp);
	$groupfile = "DESCRIPTION NoGroup Users\n";
	$groupfile .= "USERS 0\n";
	$groupfile .= "SLOTS 0 0\n";
	$groupfile .= "VFSFILE \n";
	$fp = fopen("$homedir\\output\\groups\\1","w");
	fwrite($fp,$groupfile);
	fclose($fp);

	echo "userfiles created...<br>";
	echo "groupfiles created...<br>";
	echo "UserIdTable and GroupIdTable created...<br>";

	$ident = date("ymdhis",time());
	system("$winrar m -m5 -r -ep1 -x*.rar $homedir\\output\\io$ident.rar  $homedir\\output\\*.* >nul");
	echo "files packed...<br>";
	echo "download <a href=\"output/io$ident.rar\">here</a>";
}
?>
</body>
</html>
