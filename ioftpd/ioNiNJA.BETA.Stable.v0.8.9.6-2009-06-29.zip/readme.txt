ircchan: #ioNiNJA on EFNET for support & bugreports
http://odog.tx-shells.net/
http://www.flashfxp.com/forum/showthread.php?t=12691 (forum for bugs)
http://www.flashfxp.com/forum/forumdisplay.php?f=38 (to get latest ioFTPD)

#### Thanks to:
neoxed (NXTools AlcoBot etc)
cornflake (ioSFV)
the pzs-ng team
YiL
Mediainfo creator
and alot of other people


#######################################
## 0. So whats new?                  ##
#######################################

  Been a while since last release and alot of things have changed, for more info on it then read the changelog at the end of this document.
  This is not stable at the moment. Since so much has changed, I might have stomped out a few bugs only to add others.
  This release is for beta testers only, so DO NOT EXPECT IT TO BE STABLE!
  Report the bugs you find on forum (http://www.flashfxp.com/forum/showthread.php?t=12691) or in #ioNiNJA on efnet
  Reporting bugs makes sure that they get fixed so plz take the time to do so.

  I take no responsibility for anything, if your computer burns to dust or blows up, it's on you.
  
  Read the license.txt for more info 

#######################################
## 1. INSTALLATION                   ##
#######################################

For update See changelog at the end of the file

1. unpack ioNiNJA to "path to ioftpd\scripts\ioNiNJA\"
   copy init.itcl to "../ioFTPD/scripts/"
   if it already exists copy file content from "../ioftpd/scripts/ioNiNJA/init.itcl"
   to the end of the existing file
  
   The copy the content inside ..ioFTPD/scripts/ioNiNJA/Libs/ to ..\ioFTPD\lib\tcl8.5
   
2. ADD TO IOFTPD.ini

Under [EVENTS]
OnUploadComplete        = TCL ..\scripts\ioNiNJA\ioNiNJA.itcl CHECK
OnUploadError	 	= TCL ..\scripts\ioNiNJA\ioNiNJA.itcl CHECK

Under [FTP_Pre-Command_Events]
rmd         = TCL ..\scripts\ioNiNJA\ioNiNJA.itcl

Under [FTP_Post-Command_Events]
cwd  = TCL ..\scripts\ioNiNJA\ioNiNJA.itcl
dele = TCL ..\scripts\ioNiNJA\ioNiNJA.itcl


Under [FTP_Custom_Commands]
rescan      = TCL ..\scripts\ioNiNJA\ioNiNJA.itcl RESCAN
addgroups   = TCL ..\scripts\ioNiNJA\ioNiNJA.itcl ADDGENRES
invite      = TCL ..\scripts\ioNiNJA\ioNiNJA.itcl INVITE
zsver       = TCL ..\scripts\ioNiNJA\ioNiNJA.itcl VERSION
resort      = TCL ..\scripts\ioNiNJA\ioNiNJA.itcl RESORT
symclean    = TCL ..\scripts\ioNiNJA\ioNiNJA.itcl SYMCLEAN


!!!!!!!!!!!!!!!!!!!!REMOVE ALL OTHER INVITES!!!!!!!!!!!!!!

under permissions
rescan      	  = 1M
addgroups   	  = 1M
invite      	  = 1M
zsver       	  = 1M
resort      	  = 1M
symclean          = 1M



#To get symclean to work on schedule add this under the schedule in ioFTPD.ini (Would be a good idea to check if it works with site symclean first)
ioSymClean = 59 23 * * TCL ..\scripts\ioNiNJA\ioNiNJA.itcl SYMCLEAN

3.
edit ioNiNJA.cfg
edit ..\Themes\PZS-NG.theme to fit your needs (it works as it is)
read the cookies readme in \themes for more info about themes

-Change group of dirs with mp3 in them to the genre of mp3s inside it do this.
To chgrp of mp3dirs to the mp3files genre you need to enable this in the cfg.
and do "site addgroups" This will add all genres as groups on your ftp.



4. WINDROP

  1. Copy the INCLUDED eggdrop to desired dir and edit the eggdrop.conf
  2. edit dZSbot.conf to fit your needs
  3. edit and add all the plugins you want to eggdrop.conf



RESTART EVERYTHING
Cross your fingers and hope it works!


#######################################
## 2. Troublshooting & FAQ           ##
#######################################

1. Theme is broken who do i bitch at?

   Not at me! I only maintain ioNiNJA.zst 

2. How do i report bugs?

   Either at forum: http://www.flashfxp.com/forum/showthread.php?t=12691
   Or irc: #ioNiNJA @ EFnet

3. Where do i get help configuring this script?

  NO end user support is given at the moment.

4. I have problem with windrop.

   Get used to it, windrop is crap but unfortunatly the only thing avalible. 
   
5. I have problems with zip files not containing .diz files not beeing marked as complete

   Well, zip files needs diz files in order for the script to know how many files to expect.
   There are ways around it i know, unfortunatly none of them are any good. Read the ioninja.cfg
   and you can exclude certain dirs from expecting diz files
   
6. Can you write a special script just for me?

   Unfortunatly, no. It just takes up too much time. But asking in chan on irc for new features
   etc is allowed. But respect "No" for a final answer.

7. What is a bug?

   If you do not know, it probarbly doesn't matter.
   
8. How do i use colors in themes on the bot?

   %c1{things you want colored} %b{things you want to be bold} %u{underlined} 
   %c1{things you want colored} would use color1 defined at the top of theme or if section specific colors are used it would use that.
   %c1{%b{%sitename}} would make %sitename bold and in color1 defined in script

   
9. I keep getting "FTP connection failed - server closed connection" in telenet?
   
   Exclude the sitebot username in ioftpd.ini from timeout
   
10. Can I change the interval in which the sitebot checks the bnc's?
      
   Not at the moment.
   
11. I'm using ntfs junctions but it creates problems with windows explorer when moving/removing the links
    
  http://elsdoerfer.name/=ntfslink
  That program hooks into windows explorer to handle links correctly
  
12. What is NTFS junctions? and what makes them better or worse then ioftpd symlinks?
      
    Ntfs junctions is basicly symlinks in windows. In other words the links works as regular folders in a windows enviroment.
    There are some restrictions to it. For instance NTFS junctions can not point to a network drive. But they can be shared over
    network for use with XBMC or MediaPortal.
    One things thats better with this type of symlink is that it works as a REAL directory. ioFTPD symlinks will only send you to the
    original dir and they don't work under a windows enviroment.
    In windows vista microsoft added the ability to use symlinks that work over network unfortunatly they can not be shared over networks, hence
    making them pretty useless since most symlinks are most useful on servers for creating a nice folder structure. I might add support
    for this format later on but right now the ntfs junctions actually work better.
    
    If you're only going to use ioFTPD for a server then the ioftpd symlinks might fit you best. If you going to use the server to get media from
    I would recommend junctions
    
    
 13. Why did you move most of the additions to plugins?
       
     It grew too much and got to big for it's own good.
     The plugins also run in background, meaning you wont have to wait for imdb lookup to complete when uploading nfo etc.
     
     
 14. I want custom posters to my tv shows!
            
     ioNiNJA actually saves allt he posters in scripts/ioninja/posters/
     replace the one you want or create new ones. For fanart, name the file show-fanart.jpg
     This only works for tv shows
 
 15. When downloading music covers i soemtimes get the wrong one.
     
     This feature is based on name lookup and is far from perfect. 
     It works on most retail albums and singles.
     
     
 16. When running io as a service i can't get my bot to announce !bw !speed etc.
      
      I reccomend using firedaemon to run both bot and ioftpd since they need to be able to communicate 
      with eachother over shred memory.
      
 17. Help my bot wont start!
    
     Use the windrop avalible on odog.tx-shells.net

 18. I get the message "05-07-2009 18:57:04 Error converting string: /pwd/" in systemerror.log

     This is not really an error, ignore it or go yell at YiL, Whatever you do, DON'T report it as a bug

 19. I can't get !request to work from irc

     You need to have invite enabled and NickDb.tcl loaded



PS. If you experience problems with the script then change ioNiNJA.cfg to the default one, don't change anything and see if
    the problem still exists. If it doesn't, the fault is probably in your own cfg file. Also check systemerror.log to see if it contains
    a error. Read the error before asking for help, most often it's easy to resolve.



#######################################
## 3. TODO                           ##
#######################################

1. Bug fixes

2. Add new features if any are suggested.



#######################################
## 4. CHANGELOG                      ##
#######################################

2009-06-29 - Beta 0.8.9.6:
  * imdb was screwed on some releases, fixed this
  
----------
 To update:
 replace ..ioNiNJA/plugins/imdb.itcl


2009-05-15 - Alpha 0.8.9.4:
  * Fixed a problem with mp3 sorting if nfo was uploaded last.
  
----------
 To update:
 replace ..ioNiNJA/ioNiNJA.itcl

2009-05-10 - Alpha 0.8.9.3:
  * Fixed the xxx plugin
  
----------
 To update:
 replace ..ioNiNJA/plugins/xxx.itcl


2009-05-10 - Alpha 0.8.9.2:
  * Fixed a bug, yo needed sqlite in lib dir event hough it's not used
  
----------
 To update:
 replace ..ioNiNJA/MiSC/NiNJALiB.tcl
 restart


2009-05-09 - Alpha 0.8.9.1:
  * Changed a small bug in sorting of imdb, it now can use &
  
----------
 To update:
 replace ..ioNiNJA/MiSC/NiNJALiB.tcl
 restart


2009-05-08 - Alpha 0.8.9:
  * Changed alot of things
  * Added alot of things
  * I managed to delete the changelog list, 
  * But pretty much all bugs SHOULD be fixed (the reported ones atleast)
  * Rewrote large parts of the code and the plugins
  
  * Added option to change group on all files that are uploded in order to hide grp. Will add for dirs later on.
  * option to download and name trailer as you want it
  * download fanart and create a .tbn file for people using XBMC
  * lots lots lots. I'm tired, so thats as far as I'll go atm.
  
----------
 To update:
 Do a clean install of ioNiNJA and the sitebot, since I don't have the changelog I don't know
 what's changed really. 
 Same goes for the sitebot.


2009-01-24 - Alpha 0.8.4:
  * Fixed a bug site resort mp3
  * Fixed the mp3 sorting
  
----------
 To update
 ZipScript.:  replace ../ioNiNJA/misc/NiNJALiB.tcl, ioNiNJA.itcl,ioNiNJA.cfg and copy the libs to ../ioFTPD/lib/tcl8.5/
 Plugins.:  replace sorting_mp3.itcl in plugin dir and ../scripts/ioninja/misc/ninjalib.tcl



2009-01-19 - Alpha 0.8.3:
  * Fixed a bug site resort mv
  * Resolved a bug with a timestamp.
  * Resolved a bug with speedtest
  * Now writes out sample message again.
  * download_music-cover.itcl now tries several diffrent sites to find cover. You choose the order in which to try. edit the itcl!
  * Removed the sqlite db for symlinks and moved into .ioFTPD file instead. Easier and faster.
  * Moved mp3sorting to plugin dir
  
  
----------
 To update
 ZipScript.:  replace ../ioNiNJA/misc/NiNJALiB.tcl, ioNiNJA.itcl,ioNiNJA.cfg and copy the libs to ../ioFTPD/lib/tcl8.5/
 Plugins.:  replace download_music-cover.itcl and copy sorting_mp3.itcl to plugin dir



2009-01-11 - Alpha 0.8.2:
  * Fixed a bug in banned releases.
----------
 To update
 ZipScript.:  replace ../ioNiNJA/misc/NiNJALiB.tcl




2009-01-09 - Alpha 0.8.1:
  * fixed a path in init.tcl
----------
 To update
 ZipScript.:  replace init.tcl or the content in it.
 


2009-01-09 - Alpha 0.8.0:

  Okej, alot of changes in this one, might cause some problems so I do not recommend using this other than on a test machine.
  So whats changed? 
  Theese are some of the things thats changed in new version. Most notably i moved alot of things to plugins instead of having it
  in the script.
  Moved alot of functions to a tcl that is loaded on startup instead of loaded every time the script is executed. Hopefully speeding things up a bit.
  
  The latest ioFTPD 6.9.3 is required

  EXPECT BUGS
  EXPECT BUGS
  EXPECT BUGS
  

  ioNiNJA:
  * Fixed some bugs with 0day (8-9 files) 
  * Moved ALOT of the built in features to plugins
  * Setting to hide folder.jpg
  * No longer write .message but writes the stats live on CWD
  * Changed the way sorting works
  * Added a sqlitedb with symlinks (still alpha feature) It's thought to interact with archive script so that it changes symlinks automatically and remove them on deltetion in the future
  * Fixed symlinkclean to clean up better and all theknown bugs. It now removes parent folders if it's empty after a symlink is removed.
  * Postdel is now POST del, had it on predel before. Works better now.
  * Playing around with waitobject to make race stat writing better.
  * Added a timer on the script so that you can see how long it takes to execute it.
  * Added "site resort imdb/mv/mp3/tv" command instead of the site rescan mp3/imdb etc.
  * Added date options to sorting
  * Both rescan/resort SHOULD now work over virtual raid dirs. (multiple dirs mounted as one in ioFTPD vfs)
  * Added special sorting for mp3 that removes crap from id3tags and adds info from dir. Like proper/limited etc (optional)
  * Imdb can now be performed on dir search so that it tries to find imdb info even if no imdb link is found in nfo (optional)
  * Plugins are executed either after nfo is uploaded or on completion of release. This means you no longer have to wait for the 
    script to finish with downloading information and such, all of that is done in the background.

  
 Plugins:
  * New tvshow sorting, executes on complete
  * Updated imdb
  * Download Album Cover for mp3 (not perfect but works on most albums) and save as folder.jpg
  * New release sorting, keep x number of new releases in a specific dir
  * The tv plugin also download poster from the internet to shows, they are saved in a zipfile for further use.
  
  sitebot:
  * New Sitebot
  * Added !uptime trigger with some more info
  * Fixed imdb.tcl, tvrage.tcl, topstats.tcl and top.tcl in plugins
  * No longer case sensetive on paths? (I hope)
  * Updated a few things
  * Forgot what else i added or deleted but there might be bugs.
  * Added option to ignore some users on login/logout announce


Alot more has changed but I stopped keeping track on it after a while.
The thought is to stomp out all the bugs in the script now and then rewrite some things
for a 1.0 release. 
  
----------


 To update REINSTALL EVERYTHING including the windrop.
 
 
 
 

#######################################
## 5. OLD CHANGELOG                  ##
#######################################


2008-08-20- BETA 0.7.0.1:
  * Fixed a small bug in sample
----------
 To update
 ZipScript.:  if already updated to 7.0 just replace ioninja.itcl otherwise reinstall
 Sitebot.: No changes to sitebot that i can remember other then that i added a nfo output. 
           copy it from .vars and theme file (only needed if you really want this feature)

2008-08-19- BETA 0.7.0:
  * Added a trailer download as a PLUGIN script, it downloads trailer from apple if it finds any and saves it in Trailer Dir of release.
  * Changed the way it handles imdb poster, now gets a bigger picture from imdb and uses a diffrent way to lookup impawards
  * Added option to imdb to make a imdb.html file in dir
  * %first_letter in sorting of mp3 if number 1-9 now becomes #.
  * chmod on statusbar
  * Now reads id3v2.2 .3 and .4 this will solve alot of problems with some releases not getting sorted
  * Samplecheck is now fixed and some things added and updated mediainfo
  * changed "postdel" a bit. had problems with removing symlinks
  * Moved sample message to theme, now customizable
  * alot of small changes
----------
 To update
 ZipScript.: reinstall ioNiNJA
 Sitebot.: No changes to sitebot that i can remember other then that i added a nfo output. 
           copy it from .vars and theme file (only needed if you really want this feature)


2008-05-25- BETA 0.6.1.1:
  * Should no longer timeout on cleanup
  * Fixed compability with latest ioftpd (v6.5.0)
----------
 To update
 ZipScript.: replace ioNiNJA.itcl


2008-05-09- BETA 0.6.1:
  * Rescan did not make compelte bar. Should be fixed now.
  * changed a few other things that you wont notice
----------
 To update
 ZipScript.: replace ioNiNJA.itcl



2008-05-08- BETA 0.6:
  * Fixed a bug on speedconversion to kb in dZSbot
  * Updated imdb.tcl for sitebot
  * Changed all the cookies to a more understandable format for zipscript
  * Removed a lock making sessions hang if i understand it correctly, never managed to recreate it but it should be fixed now
  * Added a new option for denying delete of complete release (group dirs excluded)
  * Changed the way sorting works, it's now pwd specific and you need to update it
  * Will no longer create incomplete links in "incomplete dir" if release is in grp dir
  * Symlink_Clean will now send msg to ioftpd stoping it from timing out in 2min (it should)
  * Added a new plugin to sort stuff after names (0day tv etc) RegExp matching
  * Should now support space char in both filenames and dirs (i have no idea why you would want this but ok)
  * Fixed a prblem with \n in diz files
  * Now it deletes old imdb bars when resorting or a new nfo is uploaded
  * Added support for nfo files in sfv (STUPID)
  * Added a option to exclude dirs from requering .diz files. This is bad only do it if you must. (NDS CRAP)
  * Fixed the Topstats.tcl, should work now
  * Updated media info
----------
 To update
 ZipScript.: Clean install (NO COPY FROM OLD CFG, themes or other stuff)
 Sitebot...: replace dZSbot.tcl,imdb.tcl & Topstats.tcl


2008-04-26- BETA 0.5.0.2:
  * Fixed a bug on reupload of sfv and nfo in compelted release
----------
 To update
 replace ioNiNJA.itcl
 

2008-04-25- BETA 0.5.0.1:
  * imdb update
----------
 To update
 replace ioNiNJA.itcl
 

2008-04-14- BETA 0.5:
  * Fixed a major bug that wouldn't announce complete if nfo was uploaded last
  * Updated the zipscript theme file, removed some things no longer used.
  * Fixed a few minor bugs
----------
 To update
 replace ioNiNJA.itcl


2008-03-31- BETA 0.4.9.1:
  * screwed up
----------
 To update
 replace ioNiNJA.itcl
 


2008-03-31- BETA 0.4.7.9:
  * fixed a bug in mv sorting causing nfo to be deleted and release marked inocomplete
  * changed the way it handles racestats
----------
 To update
 replace ioNiNJA.itcl
 


2008-03-28- BETA 0.4.7.8:
  * moved invite to ioNiNJA.itcl
  * removed some leftover debug stuff
----------
 To update
 replace ioNiNJA.itcl
 replace old invite in ioftpd.ini with:
 invite      = TCL ..\scripts\ioNiNJA\ioNiNJA.itcl INVITE
  


2008-03-27- BETA 0.4.7:
  * Changed mv sorting a little
  * Now makes symlinks point to parentdir if mp3 is taken from a defined subdir
  * Added "site zsver" command to see what version of ioNiNJA you're running
  * Fixed bug with repeated announces on races
  * bug fixed on "postdel" that would screw up when peopel tried to delete files they didn't own.
  * fixed a bug in sitebot where it didn't delete decimals from kb/s announce
  * Added the ability to execute scripts on complete
  * Changed some other things that you wont notice
  * Unpacking of archived rels are now done in a postcomplete script
  * and as always alot of smaller fixes
----------
 Do a complete reinstall of zipscrip
 To update bot replace dZSbot.tcl


2008-02-26- BETA 0.4.6.4:
  * Added a force option on sorting groups
  * now removes incomplete links on RMD (delete dir)
  * new windrop version out. windrop.1.6.18.v0.3.with.ssl.by.ronin.rar.rar USE IT
  * some things changed in sitebot.
Do a complete reinstall of: zipscrip, windrop.1.6.18.with.ssl.and.Tcl.8.5.v0.4.by.ronin.rar, sitebot


2008-02-24- BETA 0.4.6.3:
  * Alot of people were having problems with windrop, most should be fixed now
  * Don't move the libs around they should be where they are.
  * fixed a bug on !uploaders and !speed with filename
  * %sitename should now work in all theme entries
replace dZSbot.tcl

2008-02-22- BETA 0.4.6.2:
  * changed the way it loads the libs. some people were having problems.
  * fixed a very small bug in zipscript
replace ioNiNJA.itcl
replace sitebot. you can keep old themes and conf.


2008-02-19- BETA 0.4.6:
  * changed a few things in zipscript, nothing anyone should notice
  * should now return an error when file fails crc. So no dupefiles should be added
  * alot of changes to sitebot and some plugins
  * Compiled my own version of windrop to go with the script

TO UPDATE ZipSCRIPT: Replace ioNiNJA.itcl
To UPDATE SITEBOT: 
1. Download windrop.1.6.18.v0.1.with.ssl.by.ronin from odog.tx-shells.net
2. unpack it to wanted location
3. edit eggdrop.conf or copy old one
4. install new version of dZSbot and plugins.
there still are some quirks to deal with when using this build. Cygwin has a nasty habit of using POSIX.
so in free section of dZSbot.conf (!free)
/ = c:
and in the rest of the config c: = /cygdrive/c/

but it should work as intended.



2008-02-10- BETA 0.4.5.1:
* just fixed the topstats file
TO UPDATE: Replace TopStats.tcl in plugins

2008-02-10- BETA 0.4.5:
* upgraded ioninja theme
* fixed bw announce
TO UPDATE: Replace dZSbot.tcl


2008-02-10- BETA 0.4.3:
* Changed most things in bot
* does no longer have to be run in -nt mode
* removed uptime
* changed all exes against alco libs and alcoext (thanks to neoxed)
* chnged all the plugins
* Added A topstats script for daily output of stats
* ALOT MORE in sitebot
TO UPDATE: do a CLEAN install of sitebot
REPLACE: ioNiNJA.itcl


2008-01-29- BETA 0.4.3:
* fixed a mistake i made with imdb, it crashed when trying to unset a var.
* Added an option to cfg to use an /incomplete dir with incomplete links.
to update replace ioNiNJA.itcl and ioNiNJA.cfg



2008-01-28- BETA 0.4.2:
* fixes a memory problem with imdb, showed up under site rescan imdb.

2008-01-27- BETA 0.4.1:
* Sorting with ioftpd links now works

2008-01-27- BETA 0.4:
* Bug Fixed in mv sorting, it deleted nfo on some rels.
* Improved MV sorting of artists.
* Sorting in mp3 will now link subdir rels to parent dir.
* Some improvements in id3 reading, it now strips "The" infront of artist name
* site rescan has changed:
   site rescan      = help	
   site rescan this = rescan the dir you're in
   site rescan all  = rescan all subdirs under the dir you're in.
   site rescan mp3  = resorts all subdirs mp3s without checking crc or sfv.
   site rescan imdb = same as mp3 buf for imdb.
* improved impawards cover search
* it now removes m3u and nfo files from sfv.
* if nfo is uploaded after finish, it will now change complete dir and msg.
* fix nfo now trims nfos ont he right side and remove unnessecery spaces.


2008-01-04- BETA 0.3.2:
* Added VBR-NEW and VBR-OLD to mp3check.

to update: 
zipscript: replace ioninja.itcl , PZS-NG.theme
bot: replace dZSbot.vars (the var you can use in theme for bot is %audio_oldnew) it will output VBR-OLD or VBR-NEW


2007-12-31- BETA 0.3.1:
* fixed the symlinks, i kinda broke them before
replace ioninja.itcl

2007-12-31- BETA 0.3:
* Changed the way incompelte link works.
* You caa now define your own incomplete links in theme.
* Added "no_sample" option for symlink.
* Changed nxtools plugin for the bot.
* It now checks both filename and crc (previously only checked crc against sfv file)
* Rename to bad now works on rescan
* Changed the way it gets cover from impaward.
* Added top250 to imdb
* Various other small bugfixes.
* changed some things in the bot

DO A CLEAN INSTALL No upgrade possible from previous versions.
report bugs on irc (#ioNiNJA @ Efnet)



2007-12-19- BETA 0.2.8:
* Fixed problem with hiding dirs when rename group to genre on mp3
* Fixed problem with dual announce on complete (i think)
* Changed some imdb things.
* Added New theme to bot. simple.zst
* Added Cleanup of ntfs junctions to symclean. It now removes all links not working.
* some other things

To update:
replace ioNiNJA.itcl
run site addgroups if you have the rename group option on mp3 enabled.
replace dZSbot.tcl


2007-11-30- BETA 0.2.7.5:
* Fixed imdb languages and countries.
* Changed prebw.tcl to check prebw at exact times.
replace prebw.tcl & ioNiNJA.itcl

2007-11-29- BETA 0.2.7.4:
* Fixed theme in zipscript i think
* removed some debug things
just replace PZS-NG.theme & ioNiNJA.itcl to update

2007-11-29- BETA 0.2.7.3:
* Fixed top.tcl and added a few options to it
just replace top.tcl to update


2007-11-28- BETA 0.2.7.2:
* Fixed imdb genres
* Readded affils and bans to bot.
* Fixed speedtest

replace ioNiNJA.itcl to update.
replace theme file in ioninja zipscript for a small update.

for bot:
replace dZSbot.tcl and dZSbot.conf for sitebot

2007-11-21- BETA 0.2.7.1:
* switched back to curl for bnc check. People had problems with libs.
replace dZSbot.tcl to update

2007-11-21- BETA 0.2.7:
* Fixed problem with imdb and complete msg.
* fixed announce on newleader and racer.
* The bot now does the formating of variables not the zipscript.
-BOT
* Does no longer use curl on bnccheck. the variables should be fixed.
* formating is now done in the bot, creates a nicer output to irc.
* to many things to mention
* Added the ability to use !request !approve !reqfill etc etc to nxtools plugin. IT NEEDS NickDb.tcl loaded to work.

replace ioNiNJA.itcl to update
Do a complete reinstall of the bot.


2007-11-16- BETA 0.2.6.1:
+ Fixed Complete msg, it didn't write it as it should
* Fixed imdb sorting, should now work
replace ioNiNJA.itcl to update


2007-11-13- BETA 0.2.6:
+ Added the option to sort things with ntfs symlinks (read further down for more info)
* Added a section switch to !free. !free section
* Fixed another problem with diz files.
* .ioFTPD.message files are now hidden
* Fixed varaibles in dZSbot.vars, give take


Ntfs symlinks:
okej, theese kinda work like mountpoints in linux. 
the link works just like a normal dir.
The downside to theese links? 
1. network drives are not supported.
2. I have no idea how they will affect the performance of the filesystem in the long run.
3. Only work on ntfs filesystems, and only tested on windows xp.

To update zipscript: replace ioNiNJA.itcl, ioNiNJA.cfg
To update bot: replace dZSbot.vars dZSbot.tcl and theme file might need an update on give & take. use %target for user affected.

2007-11-10- BETA 0.2.5:
* Changed the way it sorts releases, you can now specify your own pattern of choise. Check .cfg file
- VA releases in mp3 will now be sorted as VA
- Rescanall should work now
* Some people like to use * in diz files causing the script not to find total number of files! This should work now.
- Some small bugfixes that you will prolly not notice
- Updated mediainfo
to update:
replace ioNiNJA.itcl & ioNiNJA.cfg then reconfigure the cfg file
replace the MiSC dir

2007-10-28- BETA 0.2.4.1:
- Fixed newracer
- Fixed rescan and upload problems hopefully
just replace ioNiNJA.itcl


2007-10-26- BETA 0.2.4:
- Fixed no announce of imdb on rescan
- Fixed sorting of 2.1gb + rels, racers are now in order
- Fixed some imd things.
just replace ioNiNJA.itcl


2007-10-19- BETA 0.2.3:
- Fixed Mp3 genre on some releases. it now detects the correct genre on some crappy rels.
just replace ioNiNJA.itcl


2007-10-18- BETA 0.2.2:
- Small fix with !up command.
just replace dZSbot.tcl and reshash and it should work


2007-10-18- BETA 0.2.1:

+ Added Several imdb directors
- Fixed Imdb sorting
- Fixed Genre on crappy tagged mp3files
- Fixed a bug with estimated size in 2.1gb+rels
- Fixed totalspeed on !up !down. And Totalsize on !free.
- Uptime in bot is now editable in theme. Avalible uptimes are %eggdrop, %time (windows), %ioftpd .
- Some more small fixes


TO UPDATE: 

replace ioNiNJA.itcl
replace dZSbot.tcl


2007-10-11 - BETA 0.2:

+ Added a Rescanall function.
- Cleaned up duplicates in theme file.
- fixed the no_nfo on multiple cd rels bug

to update replace theme file & ioNiNJA.itcl && add in ioftpd.ini:

under [FTP_Custom_Commands]
rescanall      = TCL ..\scripts\ioNiNJA\ioNiNJA.itcl RESCANALL

under PERMISSIONS
rescanall = 1M


copy the libs in sitebot\lib\ to ..\windropdir\libs\tcl8.4\




2007-10-01 - BETA 0.1.5:

+ Filename check on zipfiles. Useful to amtch zipfiles against eachother. to prevent people from uploading bad zip files.
+ Added option to search impawards for a better cover then imdb one. 



2007-09-27 - BETA 0.1:

+ now makes "no sfv" and "no nfo" incomplete symlinks.
* changed the way the theme formation works. read the cookies file in theme dir.
- fixed a problem with only 1 ( or ) in filename.
* Mixed around with unicode. feel free to try. it should work in zipscript. Not in postdel yet.
* Removed NJ_NEW and del dir. added a tagline cookie to newdir. And all scripts should work for new dir now.
+ added a tv schedule script.
* updated mediainfo.
+ Added aPrebw plugin to the sitebot.
+ alot of Other things. This is a major update and a complete reinstall is required

Do a clean isntall of both Sitebot and ZipScript


