So what are the scripts?

download_trailer     = Downloads Trailer for movies
newrelease_sorting   = Sorts new releases in a dir with symlinks
imdb                 = Sorts imdb for movies, downloads covers and backdrops
music_video          = Sorts Music Videos, creates musicvideo bar
xxx                  = Sorts XXX, creates xxx bar
regexp_sorting       = Sorts after Regexp
tv                   = sorts tv from tvrage, downloads cover/backdrop, add a tv bar
unpack_complete      = Unpacks complete releases
mp3                  = MP3 Sorting and downloads cover


1.	%a %A %b %B %C %d %e %g %G %h %I %j %k %l %m %M %p %u %U %V %w %W %y %Y
	These variables are Time variables avalible for all sorting. imdb/tv/mp3/mv/regexp etc
	But think before you use them
	To find out what they are check:
	http://www.tcl.tk/man/tcl8.4/TclCmd/clock.htm
	Notice that it is case sensetive
	
	
	