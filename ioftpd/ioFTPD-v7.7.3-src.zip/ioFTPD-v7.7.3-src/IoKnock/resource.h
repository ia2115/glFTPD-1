//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by IoKnock.rc
//
#define IDD_IOKNOCK_DIALOG              102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDI_ICON1                       138
#define IDC_PORT_1                      1000
#define IDC_PORT_2                      1001
#define IDC_PORT_3                      1002
#define IDC_PORT_4                      1003
#define IDC_PORT_5                      1004
#define IDC_CHECK1                      1005
#define IDC_CHECK2                      1006
#define IDC_CHECK3                      1007
#define IDC_CHECK4                      1008
#define IDC_CHECK5                      1009
#define IDC_SITE_COMBO                  1012
#define IDC_BUTTON_DELETE               1013
#define IDC_BUTTON_ADD                  1014
#define IDC_HOST                        1015
#define IDC_GROUP                       1016
#define IDC_BUTTON_SAVE                 1017
#define IDC_BUTTON_KNOCK                1018
#define IDC_STATUS                      1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
